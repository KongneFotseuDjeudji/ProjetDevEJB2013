/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package etats;

import java.io.Serializable;
import javax.persistence.Entity;
import javax.persistence.Id;


/**
 *
 * @author Ernest
 */
@Entity
public class EtatMatiereue implements Serializable {

    private Integer idMatiere;
    private String codematiere;
    private String libelleFr;
    private String libelleEn;
    private Integer idmatiereue;
    private int idue;
    private String codematiereue;
    private String type;
    private float credit;
    private float noteel;
    private float noteval;
    private int pourcentcc;
    private int pourcentexam;
    private int pourcenttp;
    @Id
    private Long idEtatMatiereue;
    
    public EtatMatiereue() {
    }
    
    public Integer getIdMatiere() {
        return idMatiere;
    }

    public void setIdMatiere(Integer idMatiere) {
        this.idMatiere = idMatiere;
    }

    public String getCodematiere() {
        return codematiere;
    }

    public void setCodematiere(String codematiere) {
        this.codematiere = codematiere;
    }

    public String getLibelleFr() {
        return libelleFr;
    }

    public void setLibelleFr(String libelleFr) {
        this.libelleFr = libelleFr;
    }

    public String getLibelleEn() {
        return libelleEn;
    }

    public void setLibelleEn(String libelleEn) {
        this.libelleEn = libelleEn;
    }

    public Integer getIdmatiereue() {
        return idmatiereue;
    }

    public void setIdmatiereue(Integer idmatiereue) {
        this.idmatiereue = idmatiereue;
    }

    public int getIdue() {
        return idue;
    }

    public void setIdue(int idue) {
        this.idue = idue;
    }

    public String getCodematiereue() {
        return codematiereue;
    }

    public void setCodematiereue(String codematiereue) {
        this.codematiereue = codematiereue;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public float getCredit() {
        return credit;
    }

    public void setCredit(float credit) {
        this.credit = credit;
    }

    public float getNoteel() {
        return noteel;
    }

    public void setNoteel(float noteel) {
        this.noteel = noteel;
    }

    public float getNoteval() {
        return noteval;
    }

    public void setNoteval(float noteval) {
        this.noteval = noteval;
    }

    public int getPourcentcc() {
        return pourcentcc;
    }

    public void setPourcentcc(int pourcentcc) {
        this.pourcentcc = pourcentcc;
    }

    public int getPourcentexam() {
        return pourcentexam;
    }

    public void setPourcentexam(int pourcentexam) {
        this.pourcentexam = pourcentexam;
    }

    public int getPourcenttp() {
        return pourcenttp;
    }

    public void setPourcenttp(int pourcenttp) {
        this.pourcenttp = pourcenttp;
    }

    public Long getIdEtatMatiereue() {
        return idEtatMatiereue;
    }

    public void setIdEtatMatiereue(Long idEtatMatiereue) {
        this.idEtatMatiereue = idEtatMatiereue;
    }
    
    
}

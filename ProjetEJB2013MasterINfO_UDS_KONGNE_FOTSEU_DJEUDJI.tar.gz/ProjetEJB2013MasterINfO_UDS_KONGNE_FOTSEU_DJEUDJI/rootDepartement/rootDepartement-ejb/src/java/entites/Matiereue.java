/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package entites;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author Ernest
 */
@Entity
@Table(name = "matiereue")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Matiereue.findAll", query = "SELECT m FROM Matiereue m"),
    @NamedQuery(name = "Matiereue.findByIdmatiereue", query = "SELECT m FROM Matiereue m WHERE m.idmatiereue = :idmatiereue"),
    @NamedQuery(name = "Matiereue.findByIdMatiere", query = "SELECT m FROM Matiereue m WHERE m.idMatiere = :idMatiere"),
    @NamedQuery(name = "Matiereue.findByIdue", query = "SELECT m FROM Matiereue m WHERE m.idue = :idue"),
    @NamedQuery(name = "Matiereue.findByCodematiereue", query = "SELECT m FROM Matiereue m WHERE m.codematiereue = :codematiereue"),
    @NamedQuery(name = "Matiereue.findByType", query = "SELECT m FROM Matiereue m WHERE m.type = :type"),
    @NamedQuery(name = "Matiereue.findByCredit", query = "SELECT m FROM Matiereue m WHERE m.credit = :credit"),
    @NamedQuery(name = "Matiereue.findByNoteel", query = "SELECT m FROM Matiereue m WHERE m.noteel = :noteel"),
    @NamedQuery(name = "Matiereue.findByNoteval", query = "SELECT m FROM Matiereue m WHERE m.noteval = :noteval"),
    @NamedQuery(name = "Matiereue.findByPourcentcc", query = "SELECT m FROM Matiereue m WHERE m.pourcentcc = :pourcentcc"),
    @NamedQuery(name = "Matiereue.findByPourcentexam", query = "SELECT m FROM Matiereue m WHERE m.pourcentexam = :pourcentexam"),
    @NamedQuery(name = "Matiereue.findByPourcenttp", query = "SELECT m FROM Matiereue m WHERE m.pourcenttp = :pourcenttp")})
public class Matiereue implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "idmatiereue")
    private Integer idmatiereue;
    @Basic(optional = false)
    @Column(name = "idMatiere")
    private int idMatiere;
    @Basic(optional = false)
    @Column(name = "idue")
    private int idue;
    @Basic(optional = false)
    @Column(name = "codematiereue")
    private String codematiereue;
    @Basic(optional = false)
    @Column(name = "type")
    private String type;
    @Basic(optional = false)
    @Column(name = "credit")
    private float credit;
    @Basic(optional = false)
    @Column(name = "noteel")
    private float noteel;
    @Basic(optional = false)
    @Column(name = "noteval")
    private float noteval;
    @Basic(optional = false)
    @Column(name = "pourcentcc")
    private int pourcentcc;
    @Basic(optional = false)
    @Column(name = "pourcentexam")
    private int pourcentexam;
    @Basic(optional = false)
    @Column(name = "pourcenttp")
    private int pourcenttp;

    public Matiereue() {
    }

    public Matiereue(Integer idmatiereue) {
        this.idmatiereue = idmatiereue;
    }

    public Matiereue(Integer idmatiereue, int idMatiere, int idue, String codematiereue, String type, float credit, float noteel, float noteval, int pourcentcc, int pourcentexam, int pourcenttp) {
        this.idmatiereue = idmatiereue;
        this.idMatiere = idMatiere;
        this.idue = idue;
        this.codematiereue = codematiereue;
        this.type = type;
        this.credit = credit;
        this.noteel = noteel;
        this.noteval = noteval;
        this.pourcentcc = pourcentcc;
        this.pourcentexam = pourcentexam;
        this.pourcenttp = pourcenttp;
    }

    public Integer getIdmatiereue() {
        return idmatiereue;
    }

    public void setIdmatiereue(Integer idmatiereue) {
        this.idmatiereue = idmatiereue;
    }

    public int getIdMatiere() {
        return idMatiere;
    }

    public void setIdMatiere(int idMatiere) {
        this.idMatiere = idMatiere;
    }

    public int getIdue() {
        return idue;
    }

    public void setIdue(int idue) {
        this.idue = idue;
    }

    public String getCodematiereue() {
        return codematiereue;
    }

    public void setCodematiereue(String codematiereue) {
        this.codematiereue = codematiereue;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public float getCredit() {
        return credit;
    }

    public void setCredit(float credit) {
        this.credit = credit;
    }

    public float getNoteel() {
        return noteel;
    }

    public void setNoteel(float noteel) {
        this.noteel = noteel;
    }

    public float getNoteval() {
        return noteval;
    }

    public void setNoteval(float noteval) {
        this.noteval = noteval;
    }

    public int getPourcentcc() {
        return pourcentcc;
    }

    public void setPourcentcc(int pourcentcc) {
        this.pourcentcc = pourcentcc;
    }

    public int getPourcentexam() {
        return pourcentexam;
    }

    public void setPourcentexam(int pourcentexam) {
        this.pourcentexam = pourcentexam;
    }

    public int getPourcenttp() {
        return pourcenttp;
    }

    public void setPourcenttp(int pourcenttp) {
        this.pourcenttp = pourcenttp;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idmatiereue != null ? idmatiereue.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Matiereue)) {
            return false;
        }
        Matiereue other = (Matiereue) object;
        if ((this.idmatiereue == null && other.idmatiereue != null) || (this.idmatiereue != null && !this.idmatiereue.equals(other.idmatiereue))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "entites.Matiereue[ idmatiereue=" + idmatiereue + " ]";
    }
    
}

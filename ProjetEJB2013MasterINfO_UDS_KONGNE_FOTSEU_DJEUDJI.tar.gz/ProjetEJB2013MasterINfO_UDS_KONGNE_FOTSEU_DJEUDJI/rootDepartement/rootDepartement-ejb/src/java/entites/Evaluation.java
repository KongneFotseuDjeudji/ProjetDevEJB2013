/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package entites;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author Thierrynems
 */
@Entity
@Table(name = "evaluation")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Evaluation.findAll", query = "SELECT e FROM Evaluation e"),
    @NamedQuery(name = "Evaluation.findByIdevaluation", query = "SELECT e FROM Evaluation e WHERE e.idevaluation = :idevaluation"),
    @NamedQuery(name = "Evaluation.findByIdMatiere", query = "SELECT e FROM Evaluation e WHERE e.idMatiere = :idMatiere"),
    @NamedQuery(name = "Evaluation.findByIdoptionsemestre", query = "SELECT e FROM Evaluation e WHERE e.idoptionsemestre = :idoptionsemestre"),
    @NamedQuery(name = "Evaluation.findByIdSession", query = "SELECT e FROM Evaluation e WHERE e.idSession = :idSession"),
    @NamedQuery(name = "Evaluation.findByIdtypeevaluation", query = "SELECT e FROM Evaluation e WHERE e.idtypeevaluation = :idtypeevaluation"),
    @NamedQuery(name = "Evaluation.findByCodeevaluation", query = "SELECT e FROM Evaluation e WHERE e.codeevaluation = :codeevaluation"),
    @NamedQuery(name = "Evaluation.findByIsanonyme", query = "SELECT e FROM Evaluation e WHERE e.isanonyme = :isanonyme"),
    @NamedQuery(name = "Evaluation.findByPoidseval", query = "SELECT e FROM Evaluation e WHERE e.poidseval = :poidseval"),
    @NamedQuery(name = "Evaluation.findByDateeval", query = "SELECT e FROM Evaluation e WHERE e.dateeval = :dateeval"),
    @NamedQuery(name = "Evaluation.findByHeure", query = "SELECT e FROM Evaluation e WHERE e.heure = :heure"),
    @NamedQuery(name = "Evaluation.findByVerrouevaluation", query = "SELECT e FROM Evaluation e WHERE e.verrouevaluation = :verrouevaluation"),
    @NamedQuery(name = "Evaluation.findBySessionSemestre", query = "SELECT e FROM Evaluation e WHERE e.idoptionsemestre = :idoptionsemestre AND e.idMatiere = :idMatiere AND e.idSession = :idSession AND e.idtypeevaluation = :idtypeevaluation")
})
public class Evaluation implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "idevaluation")
    private Integer idevaluation;
    @Basic(optional = false)
    @Column(name = "idMatiere")
    private int idMatiere;
    @Basic(optional = false)
    @Column(name = "idoptionsemestre")
    private int idoptionsemestre;
    @Basic(optional = false)
    @Column(name = "idSession")
    private int idSession;
    @Basic(optional = false)
    @Column(name = "idtypeevaluation")
    private int idtypeevaluation;
    @Basic(optional = false)
    @Column(name = "codeevaluation")
    private String codeevaluation;
    @Basic(optional = false)
    @Column(name = "isanonyme")
    private boolean isanonyme;
    @Basic(optional = false)
    @Column(name = "poidseval")
    private int poidseval;
    @Basic(optional = false)
    @Column(name = "dateeval")
    @Temporal(TemporalType.DATE)
    private Date dateeval;
    @Column(name = "Heure")
    @Temporal(TemporalType.TIME)
    private Date heure;
    @Basic(optional = false)
    @Column(name = "verrouevaluation")
    private int verrouevaluation;

    public Evaluation() {
    }

    public Evaluation(Integer idevaluation) {
        this.idevaluation = idevaluation;
    }

    public Evaluation(Integer idevaluation, int idMatiere, int idoptionsemestre, int idSession, int idtypeevaluation, String codeevaluation, boolean isanonyme, int poidseval, Date dateeval, int verrouevaluation) {
        this.idevaluation = idevaluation;
        this.idMatiere = idMatiere;
        this.idoptionsemestre = idoptionsemestre;
        this.idSession = idSession;
        this.idtypeevaluation = idtypeevaluation;
        this.codeevaluation = codeevaluation;
        this.isanonyme = isanonyme;
        this.poidseval = poidseval;
        this.dateeval = dateeval;
        this.verrouevaluation = verrouevaluation;
    }

    public Integer getIdevaluation() {
        return idevaluation;
    }

    public void setIdevaluation(Integer idevaluation) {
        this.idevaluation = idevaluation;
    }

    public int getIdMatiere() {
        return idMatiere;
    }

    public void setIdMatiere(int idMatiere) {
        this.idMatiere = idMatiere;
    }

    public int getIdoptionsemestre() {
        return idoptionsemestre;
    }

    public void setIdoptionsemestre(int idoptionsemestre) {
        this.idoptionsemestre = idoptionsemestre;
    }

    public int getIdSession() {
        return idSession;
    }

    public void setIdSession(int idSession) {
        this.idSession = idSession;
    }

    public int getIdtypeevaluation() {
        return idtypeevaluation;
    }

    public void setIdtypeevaluation(int idtypeevaluation) {
        this.idtypeevaluation = idtypeevaluation;
    }

    public String getCodeevaluation() {
        return codeevaluation;
    }

    public void setCodeevaluation(String codeevaluation) {
        this.codeevaluation = codeevaluation;
    }

    public boolean getIsanonyme() {
        return isanonyme;
    }

    public void setIsanonyme(boolean isanonyme) {
        this.isanonyme = isanonyme;
    }

    public int getPoidseval() {
        return poidseval;
    }

    public void setPoidseval(int poidseval) {
        this.poidseval = poidseval;
    }

    public Date getDateeval() {
        return dateeval;
    }

    public void setDateeval(Date dateeval) {
        this.dateeval = dateeval;
    }

    public Date getHeure() {
        return heure;
    }

    public void setHeure(Date heure) {
        this.heure = heure;
    }

    public int getVerrouevaluation() {
        return verrouevaluation;
    }

    public void setVerrouevaluation(int verrouevaluation) {
        this.verrouevaluation = verrouevaluation;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idevaluation != null ? idevaluation.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Evaluation)) {
            return false;
        }
        Evaluation other = (Evaluation) object;
        if ((this.idevaluation == null && other.idevaluation != null) || (this.idevaluation != null && !this.idevaluation.equals(other.idevaluation))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "entites.Evaluation[ idevaluation=" + idevaluation + " ]";
    }
    
}

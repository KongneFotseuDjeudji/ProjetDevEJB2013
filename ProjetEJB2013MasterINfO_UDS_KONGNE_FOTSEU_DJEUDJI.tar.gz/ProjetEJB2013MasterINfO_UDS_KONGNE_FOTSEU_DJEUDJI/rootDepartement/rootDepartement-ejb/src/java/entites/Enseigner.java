/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package entites;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author Thierrynems
 */
@Entity
@Table(name = "enseigner")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Enseigner.findAll", query = "SELECT e FROM Enseigner e"),
    @NamedQuery(name = "Enseigner.findByIdEnseigner", query = "SELECT e FROM Enseigner e WHERE e.idEnseigner = :idEnseigner"),
    @NamedQuery(name = "Enseigner.findByIdEnseignant", query = "SELECT e FROM Enseigner e WHERE e.idEnseignant = :idEnseignant"),
    @NamedQuery(name = "Enseigner.findByIdsalle", query = "SELECT e FROM Enseigner e WHERE e.idsalle = :idsalle"),
    @NamedQuery(name = "Enseigner.findByIdSession", query = "SELECT e FROM Enseigner e WHERE e.idSession = :idSession"),
    @NamedQuery(name = "Enseigner.findByIdMatiere", query = "SELECT e FROM Enseigner e WHERE e.idMatiere = :idMatiere"),
    @NamedQuery(name = "Enseigner.findByIdoptionsemestre", query = "SELECT e FROM Enseigner e WHERE e.idoptionsemestre = :idoptionsemestre"),
    @NamedQuery(name = "Enseigner.findByIdplagehoraire", query = "SELECT e FROM Enseigner e WHERE e.idplagehoraire = :idplagehoraire"),
    @NamedQuery(name = "Enseigner.findByCodeenseigner", query = "SELECT e FROM Enseigner e WHERE e.codeenseigner = :codeenseigner"),
    @NamedQuery(name = "Enseigner.findByDate", query = "SELECT e FROM Enseigner e WHERE e.date = :date")})
public class Enseigner implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "idEnseigner")
    private Integer idEnseigner;
    @Basic(optional = false)
    @Column(name = "idEnseignant")
    private int idEnseignant;
    @Basic(optional = false)
    @Column(name = "idsalle")
    private int idsalle;
    @Basic(optional = false)
    @Column(name = "idSession")
    private int idSession;
    @Basic(optional = false)
    @Column(name = "idMatiere")
    private int idMatiere;
    @Basic(optional = false)
    @Column(name = "idoptionsemestre")
    private int idoptionsemestre;
    @Basic(optional = false)
    @Column(name = "idplagehoraire")
    private int idplagehoraire;
    @Column(name = "codeenseigner")
    private String codeenseigner;
    @Column(name = "date")
    @Temporal(TemporalType.DATE)
    private Date date;

    public Enseigner() {
    }

    public Enseigner(Integer idEnseigner) {
        this.idEnseigner = idEnseigner;
    }

    public Enseigner(Integer idEnseigner, int idEnseignant, int idsalle, int idSession, int idMatiere, int idoptionsemestre, int idplagehoraire) {
        this.idEnseigner = idEnseigner;
        this.idEnseignant = idEnseignant;
        this.idsalle = idsalle;
        this.idSession = idSession;
        this.idMatiere = idMatiere;
        this.idoptionsemestre = idoptionsemestre;
        this.idplagehoraire = idplagehoraire;
    }

    public Integer getIdEnseigner() {
        return idEnseigner;
    }

    public void setIdEnseigner(Integer idEnseigner) {
        this.idEnseigner = idEnseigner;
    }

    public int getIdEnseignant() {
        return idEnseignant;
    }

    public void setIdEnseignant(int idEnseignant) {
        this.idEnseignant = idEnseignant;
    }

    public int getIdsalle() {
        return idsalle;
    }

    public void setIdsalle(int idsalle) {
        this.idsalle = idsalle;
    }

    public int getIdSession() {
        return idSession;
    }

    public void setIdSession(int idSession) {
        this.idSession = idSession;
    }

    public int getIdMatiere() {
        return idMatiere;
    }

    public void setIdMatiere(int idMatiere) {
        this.idMatiere = idMatiere;
    }

    public int getIdoptionsemestre() {
        return idoptionsemestre;
    }

    public void setIdoptionsemestre(int idoptionsemestre) {
        this.idoptionsemestre = idoptionsemestre;
    }

    public int getIdplagehoraire() {
        return idplagehoraire;
    }

    public void setIdplagehoraire(int idplagehoraire) {
        this.idplagehoraire = idplagehoraire;
    }

    public String getCodeenseigner() {
        return codeenseigner;
    }

    public void setCodeenseigner(String codeenseigner) {
        this.codeenseigner = codeenseigner;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idEnseigner != null ? idEnseigner.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Enseigner)) {
            return false;
        }
        Enseigner other = (Enseigner) object;
        if ((this.idEnseigner == null && other.idEnseigner != null) || (this.idEnseigner != null && !this.idEnseigner.equals(other.idEnseigner))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "entites.Enseigner[ idEnseigner=" + idEnseigner + " ]";
    }
    
}

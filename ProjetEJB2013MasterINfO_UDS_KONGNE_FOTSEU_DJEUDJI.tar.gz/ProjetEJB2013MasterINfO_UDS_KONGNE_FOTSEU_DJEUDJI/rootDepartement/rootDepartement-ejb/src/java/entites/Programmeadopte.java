/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package entites;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author Ernest
 */
@Entity
@Table(name = "programmeadopte")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Programmeadopte.findAll", query = "SELECT p FROM Programmeadopte p"),
    @NamedQuery(name = "Programmeadopte.findByIdprogrammeadopte", query = "SELECT p FROM Programmeadopte p WHERE p.idprogrammeadopte = :idprogrammeadopte"),
    @NamedQuery(name = "Programmeadopte.findByIdannee", query = "SELECT p FROM Programmeadopte p WHERE p.idannee = :idannee"),
    @NamedQuery(name = "Programmeadopte.findByIdoptions", query = "SELECT p FROM Programmeadopte p WHERE p.idoptions = :idoptions"),
    @NamedQuery(name = "Programmeadopte.findByIdProgramme", query = "SELECT p FROM Programmeadopte p WHERE p.idProgramme = :idProgramme"),
    @NamedQuery(name = "Programmeadopte.findByIdsemestre", query = "SELECT p FROM Programmeadopte p WHERE p.idsemestre = :idsemestre")})
public class Programmeadopte implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "idprogrammeadopte")
    private Integer idprogrammeadopte;
    @Basic(optional = false)
    @Column(name = "idannee")
    private int idannee;
    @Basic(optional = false)
    @Column(name = "idoptions")
    private int idoptions;
    @Basic(optional = false)
    @Column(name = "idProgramme")
    private int idProgramme;
    @Basic(optional = false)
    @Column(name = "idsemestre")
    private int idsemestre;

    public Programmeadopte() {
    }

    public Programmeadopte(Integer idprogrammeadopte) {
        this.idprogrammeadopte = idprogrammeadopte;
    }

    public Programmeadopte(Integer idprogrammeadopte, int idannee, int idoptions, int idProgramme, int idsemestre) {
        this.idprogrammeadopte = idprogrammeadopte;
        this.idannee = idannee;
        this.idoptions = idoptions;
        this.idProgramme = idProgramme;
        this.idsemestre = idsemestre;
    }

    public Integer getIdprogrammeadopte() {
        return idprogrammeadopte;
    }

    public void setIdprogrammeadopte(Integer idprogrammeadopte) {
        this.idprogrammeadopte = idprogrammeadopte;
    }

    public int getIdannee() {
        return idannee;
    }

    public void setIdannee(int idannee) {
        this.idannee = idannee;
    }

    public int getIdoptions() {
        return idoptions;
    }

    public void setIdoptions(int idoptions) {
        this.idoptions = idoptions;
    }

    public int getIdProgramme() {
        return idProgramme;
    }

    public void setIdProgramme(int idProgramme) {
        this.idProgramme = idProgramme;
    }

    public int getIdsemestre() {
        return idsemestre;
    }

    public void setIdsemestre(int idsemestre) {
        this.idsemestre = idsemestre;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idprogrammeadopte != null ? idprogrammeadopte.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Programmeadopte)) {
            return false;
        }
        Programmeadopte other = (Programmeadopte) object;
        if ((this.idprogrammeadopte == null && other.idprogrammeadopte != null) || (this.idprogrammeadopte != null && !this.idprogrammeadopte.equals(other.idprogrammeadopte))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "entites.Programmeadopte[ idprogrammeadopte=" + idprogrammeadopte + " ]";
    }
    
}

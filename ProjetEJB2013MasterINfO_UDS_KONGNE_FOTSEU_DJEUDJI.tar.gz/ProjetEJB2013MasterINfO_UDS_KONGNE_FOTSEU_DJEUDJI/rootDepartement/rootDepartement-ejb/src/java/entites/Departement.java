/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package entites;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author Thierrynems
 */
@Entity
@Table(name = "departement")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Departement.findAll", query = "SELECT d FROM Departement d"),
    @NamedQuery(name = "Departement.findByIddepartement", query = "SELECT d FROM Departement d WHERE d.iddepartement = :iddepartement"),
    @NamedQuery(name = "Departement.findByIdEtablissement", query = "SELECT d FROM Departement d WHERE d.idEtablissement = :idEtablissement"),
    @NamedQuery(name = "Departement.findByCode", query = "SELECT d FROM Departement d WHERE d.code = :code"),
    @NamedQuery(name = "Departement.findByLibelleFr", query = "SELECT d FROM Departement d WHERE d.libelleFr = :libelleFr"),
    @NamedQuery(name = "Departement.findByLibelleEn", query = "SELECT d FROM Departement d WHERE d.libelleEn = :libelleEn")})
public class Departement implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "iddepartement")
    private Integer iddepartement;
    @Basic(optional = false)
    @Column(name = "idEtablissement")
    private int idEtablissement;
    @Basic(optional = false)
    @Column(name = "code")
    private String code;
    @Basic(optional = false)
    @Column(name = "libelle_fr")
    private String libelleFr;
    @Basic(optional = false)
    @Column(name = "libelle_en")
    private String libelleEn;

    public Departement() {
    }

    public Departement(Integer iddepartement) {
        this.iddepartement = iddepartement;
    }

    public Departement(Integer iddepartement, int idEtablissement, String code, String libelleFr, String libelleEn) {
        this.iddepartement = iddepartement;
        this.idEtablissement = idEtablissement;
        this.code = code;
        this.libelleFr = libelleFr;
        this.libelleEn = libelleEn;
    }

    public Integer getIddepartement() {
        return iddepartement;
    }

    public void setIddepartement(Integer iddepartement) {
        this.iddepartement = iddepartement;
    }

    public int getIdEtablissement() {
        return idEtablissement;
    }

    public void setIdEtablissement(int idEtablissement) {
        this.idEtablissement = idEtablissement;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getLibelleFr() {
        return libelleFr;
    }

    public void setLibelleFr(String libelleFr) {
        this.libelleFr = libelleFr;
    }

    public String getLibelleEn() {
        return libelleEn;
    }

    public void setLibelleEn(String libelleEn) {
        this.libelleEn = libelleEn;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (iddepartement != null ? iddepartement.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Departement)) {
            return false;
        }
        Departement other = (Departement) object;
        if ((this.iddepartement == null && other.iddepartement != null) || (this.iddepartement != null && !this.iddepartement.equals(other.iddepartement))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "entites.Departement[ iddepartement=" + iddepartement + " ]";
    }
    
}

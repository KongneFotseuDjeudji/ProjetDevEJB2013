/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package entites;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author Ernest
 */
@Entity
@Table(name = "matiereprogrammee")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Matiereprogrammee.findAll", query = "SELECT m FROM Matiereprogrammee m"),
    @NamedQuery(name = "Matiereprogrammee.findByIdMatiereProgrammee", query = "SELECT m FROM Matiereprogrammee m WHERE m.idMatiereProgrammee = :idMatiereProgrammee"),
    @NamedQuery(name = "Matiereprogrammee.findByIdplagehoraire", query = "SELECT m FROM Matiereprogrammee m WHERE m.idplagehoraire = :idplagehoraire"),
    @NamedQuery(name = "Matiereprogrammee.findByIdsalle", query = "SELECT m FROM Matiereprogrammee m WHERE m.idsalle = :idsalle"),
    @NamedQuery(name = "Matiereprogrammee.findByIdMatiere", query = "SELECT m FROM Matiereprogrammee m WHERE m.idMatiere = :idMatiere"),
    @NamedQuery(name = "Matiereprogrammee.findByIdoptionsemestre", query = "SELECT m FROM Matiereprogrammee m WHERE m.idoptionsemestre = :idoptionsemestre"),
    @NamedQuery(name = "Matiereprogrammee.findByIdSession", query = "SELECT m FROM Matiereprogrammee m WHERE m.idSession = :idSession"),
    @NamedQuery(name = "Matiereprogrammee.findByCodeprogrammtion", query = "SELECT m FROM Matiereprogrammee m WHERE m.codeprogrammtion = :codeprogrammtion"),
    @NamedQuery(name = "Matiereprogrammee.findByDateprogrammee", query = "SELECT m FROM Matiereprogrammee m WHERE m.dateprogrammee = :dateprogrammee")})
public class Matiereprogrammee implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "idMatiereProgrammee")
    private Integer idMatiereProgrammee;
    @Basic(optional = false)
    @Column(name = "idplagehoraire")
    private int idplagehoraire;
    @Basic(optional = false)
    @Column(name = "idsalle")
    private int idsalle;
    @Basic(optional = false)
    @Column(name = "idMatiere")
    private int idMatiere;
    @Basic(optional = false)
    @Column(name = "idoptionsemestre")
    private int idoptionsemestre;
    @Basic(optional = false)
    @Column(name = "idSession")
    private int idSession;
    @Basic(optional = false)
    @Column(name = "codeprogrammtion")
    private String codeprogrammtion;
    @Basic(optional = false)
    @Column(name = "dateprogrammee")
    @Temporal(TemporalType.DATE)
    private Date dateprogrammee;

    public Matiereprogrammee() {
    }

    public Matiereprogrammee(Integer idMatiereProgrammee) {
        this.idMatiereProgrammee = idMatiereProgrammee;
    }

    public Matiereprogrammee(Integer idMatiereProgrammee, int idplagehoraire, int idsalle, int idMatiere, int idoptionsemestre, int idSession, String codeprogrammtion, Date dateprogrammee) {
        this.idMatiereProgrammee = idMatiereProgrammee;
        this.idplagehoraire = idplagehoraire;
        this.idsalle = idsalle;
        this.idMatiere = idMatiere;
        this.idoptionsemestre = idoptionsemestre;
        this.idSession = idSession;
        this.codeprogrammtion = codeprogrammtion;
        this.dateprogrammee = dateprogrammee;
    }

    public Integer getIdMatiereProgrammee() {
        return idMatiereProgrammee;
    }

    public void setIdMatiereProgrammee(Integer idMatiereProgrammee) {
        this.idMatiereProgrammee = idMatiereProgrammee;
    }

    public int getIdplagehoraire() {
        return idplagehoraire;
    }

    public void setIdplagehoraire(int idplagehoraire) {
        this.idplagehoraire = idplagehoraire;
    }

    public int getIdsalle() {
        return idsalle;
    }

    public void setIdsalle(int idsalle) {
        this.idsalle = idsalle;
    }

    public int getIdMatiere() {
        return idMatiere;
    }

    public void setIdMatiere(int idMatiere) {
        this.idMatiere = idMatiere;
    }

    public int getIdoptionsemestre() {
        return idoptionsemestre;
    }

    public void setIdoptionsemestre(int idoptionsemestre) {
        this.idoptionsemestre = idoptionsemestre;
    }

    public int getIdSession() {
        return idSession;
    }

    public void setIdSession(int idSession) {
        this.idSession = idSession;
    }

    public String getCodeprogrammtion() {
        return codeprogrammtion;
    }

    public void setCodeprogrammtion(String codeprogrammtion) {
        this.codeprogrammtion = codeprogrammtion;
    }

    public Date getDateprogrammee() {
        return dateprogrammee;
    }

    public void setDateprogrammee(Date dateprogrammee) {
        this.dateprogrammee = dateprogrammee;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idMatiereProgrammee != null ? idMatiereProgrammee.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Matiereprogrammee)) {
            return false;
        }
        Matiereprogrammee other = (Matiereprogrammee) object;
        if ((this.idMatiereProgrammee == null && other.idMatiereProgrammee != null) || (this.idMatiereProgrammee != null && !this.idMatiereProgrammee.equals(other.idMatiereProgrammee))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "entites.Matiereprogrammee[ idMatiereProgrammee=" + idMatiereProgrammee + " ]";
    }
    
}

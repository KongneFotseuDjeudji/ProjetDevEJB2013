/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package entites;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author Thierrynems
 */
@Entity
@Table(name = "utilisateur")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Utilisateur.findAll", query = "SELECT u FROM Utilisateur u"),
    @NamedQuery(name = "Utilisateur.findByIdusers", query = "SELECT u FROM Utilisateur u WHERE u.idusers = :idusers"),
    @NamedQuery(name = "Utilisateur.findByIdgroupuser", query = "SELECT u FROM Utilisateur u WHERE u.idgroupuser = :idgroupuser"),
    @NamedQuery(name = "Utilisateur.findByLogin", query = "SELECT u FROM Utilisateur u WHERE u.login = :login"),
    @NamedQuery(name = "Utilisateur.findByLoginPasswd", query = "SELECT u FROM Utilisateur u WHERE u.login = :login AND u.passwd = :passwd"),
    @NamedQuery(name = "Utilisateur.findByPasswd", query = "SELECT u FROM Utilisateur u WHERE u.passwd = :passwd"),
    @NamedQuery(name = "Utilisateur.findByNomcomplet", query = "SELECT u FROM Utilisateur u WHERE u.nomcomplet = :nomcomplet"),
    @NamedQuery(name = "Utilisateur.findByActive", query = "SELECT u FROM Utilisateur u WHERE u.active = :active")})
public class Utilisateur implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "idusers")
    private Integer idusers;
    @Basic(optional = false)
    @Column(name = "idgroupuser")
    private int idgroupuser;
    @Column(name = "login")
    private String login;
    @Column(name = "passwd")
    private String passwd;
    @Column(name = "nomcomplet")
    private String nomcomplet;
    @Column(name = "active")
    private Integer active;

    public Utilisateur() {
    }

    public Utilisateur(Integer idusers) {
        this.idusers = idusers;
    }

    public Utilisateur(Integer idusers, int idgroupuser) {
        this.idusers = idusers;
        this.idgroupuser = idgroupuser;
    }

    public Integer getIdusers() {
        return idusers;
    }

    public void setIdusers(Integer idusers) {
        this.idusers = idusers;
    }

    public int getIdgroupuser() {
        return idgroupuser;
    }

    public void setIdgroupuser(int idgroupuser) {
        this.idgroupuser = idgroupuser;
    }

    public String getLogin() {
        return login;
    }

    public void setLogin(String login) {
        this.login = login;
    }

    public String getPasswd() {
        return passwd;
    }

    public void setPasswd(String passwd) {
        this.passwd = passwd;
    }

    public String getNomcomplet() {
        return nomcomplet;
    }

    public void setNomcomplet(String nomcomplet) {
        this.nomcomplet = nomcomplet;
    }

    public Integer getActive() {
        return active;
    }

    public void setActive(Integer active) {
        this.active = active;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idusers != null ? idusers.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Utilisateur)) {
            return false;
        }
        Utilisateur other = (Utilisateur) object;
        if ((this.idusers == null && other.idusers != null) || (this.idusers != null && !this.idusers.equals(other.idusers))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "entites.Utilisateur[ idusers=" + idusers + " ]";
    }
    
}

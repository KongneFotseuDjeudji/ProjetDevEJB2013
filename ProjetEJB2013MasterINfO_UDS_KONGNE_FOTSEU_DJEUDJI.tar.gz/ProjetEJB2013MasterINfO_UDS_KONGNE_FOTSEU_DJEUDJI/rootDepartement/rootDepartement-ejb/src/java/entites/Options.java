/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package entites;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author Thierrynems
 */
@Entity
@Table(name = "options")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Options.findAll", query = "SELECT o FROM Options o"),
    @NamedQuery(name = "Options.findByIdoptions", query = "SELECT o FROM Options o WHERE o.idoptions = :idoptions"),
    @NamedQuery(name = "Options.findByIdCursus", query = "SELECT o FROM Options o WHERE o.idCursus = :idCursus"),
    @NamedQuery(name = "Options.findByCodeoption", query = "SELECT o FROM Options o WHERE o.codeoption = :codeoption"),
    @NamedQuery(name = "Options.findByLibelleFr", query = "SELECT o FROM Options o WHERE o.libelleFr = :libelleFr"),
    @NamedQuery(name = "Options.findByLibelleEn", query = "SELECT o FROM Options o WHERE o.libelleEn = :libelleEn"),
    @NamedQuery(name = "Options.findByDatecreation", query = "SELECT o FROM Options o WHERE o.datecreation = :datecreation")})
public class Options implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "idoptions")
    private Integer idoptions;
    @Basic(optional = false)
    @Column(name = "idCursus")
    private int idCursus;
    @Basic(optional = false)
    @Column(name = "codeoption")
    private String codeoption;
    @Basic(optional = false)
    @Column(name = "libelle_fr")
    private String libelleFr;
    @Basic(optional = false)
    @Column(name = "libelle_en")
    private String libelleEn;
    @Basic(optional = false)
    @Column(name = "datecreation")
    @Temporal(TemporalType.DATE)
    private Date datecreation;

    public Options() {
    }

    public Options(Integer idoptions) {
        this.idoptions = idoptions;
    }

    public Options(Integer idoptions, int idCursus, String codeoption, String libelleFr, String libelleEn, Date datecreation) {
        this.idoptions = idoptions;
        this.idCursus = idCursus;
        this.codeoption = codeoption;
        this.libelleFr = libelleFr;
        this.libelleEn = libelleEn;
        this.datecreation = datecreation;
    }

    public Integer getIdoptions() {
        return idoptions;
    }

    public void setIdoptions(Integer idoptions) {
        this.idoptions = idoptions;
    }

    public int getIdCursus() {
        return idCursus;
    }

    public void setIdCursus(int idCursus) {
        this.idCursus = idCursus;
    }

    public String getCodeoption() {
        return codeoption;
    }

    public void setCodeoption(String codeoption) {
        this.codeoption = codeoption;
    }

    public String getLibelleFr() {
        return libelleFr;
    }

    public void setLibelleFr(String libelleFr) {
        this.libelleFr = libelleFr;
    }

    public String getLibelleEn() {
        return libelleEn;
    }

    public void setLibelleEn(String libelleEn) {
        this.libelleEn = libelleEn;
    }

    public Date getDatecreation() {
        return datecreation;
    }

    public void setDatecreation(Date datecreation) {
        this.datecreation = datecreation;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idoptions != null ? idoptions.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Options)) {
            return false;
        }
        Options other = (Options) object;
        if ((this.idoptions == null && other.idoptions != null) || (this.idoptions != null && !this.idoptions.equals(other.idoptions))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "entites.Options[ idoptions=" + idoptions + " ]";
    }
    
}

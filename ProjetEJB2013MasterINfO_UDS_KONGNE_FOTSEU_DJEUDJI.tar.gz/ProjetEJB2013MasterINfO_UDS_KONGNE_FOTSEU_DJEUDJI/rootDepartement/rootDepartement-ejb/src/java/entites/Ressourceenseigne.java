/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package entites;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author Ernest
 */
@Entity
@Table(name = "ressourceenseigne")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Ressourceenseigne.findAll", query = "SELECT r FROM Ressourceenseigne r"),
    @NamedQuery(name = "Ressourceenseigne.findByIdressourceenseigne", query = "SELECT r FROM Ressourceenseigne r WHERE r.idressourceenseigne = :idressourceenseigne"),
    @NamedQuery(name = "Ressourceenseigne.findByIdressources", query = "SELECT r FROM Ressourceenseigne r WHERE r.idressources = :idressources"),
    @NamedQuery(name = "Ressourceenseigne.findByIdEnseigner", query = "SELECT r FROM Ressourceenseigne r WHERE r.idEnseigner = :idEnseigner")})
public class Ressourceenseigne implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "idressourceenseigne")
    private Integer idressourceenseigne;
    @Basic(optional = false)
    @Column(name = "idressources")
    private int idressources;
    @Basic(optional = false)
    @Column(name = "idEnseigner")
    private int idEnseigner;

    public Ressourceenseigne() {
    }

    public Ressourceenseigne(Integer idressourceenseigne) {
        this.idressourceenseigne = idressourceenseigne;
    }

    public Ressourceenseigne(Integer idressourceenseigne, int idressources, int idEnseigner) {
        this.idressourceenseigne = idressourceenseigne;
        this.idressources = idressources;
        this.idEnseigner = idEnseigner;
    }

    public Integer getIdressourceenseigne() {
        return idressourceenseigne;
    }

    public void setIdressourceenseigne(Integer idressourceenseigne) {
        this.idressourceenseigne = idressourceenseigne;
    }

    public int getIdressources() {
        return idressources;
    }

    public void setIdressources(int idressources) {
        this.idressources = idressources;
    }

    public int getIdEnseigner() {
        return idEnseigner;
    }

    public void setIdEnseigner(int idEnseigner) {
        this.idEnseigner = idEnseigner;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idressourceenseigne != null ? idressourceenseigne.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Ressourceenseigne)) {
            return false;
        }
        Ressourceenseigne other = (Ressourceenseigne) object;
        if ((this.idressourceenseigne == null && other.idressourceenseigne != null) || (this.idressourceenseigne != null && !this.idressourceenseigne.equals(other.idressourceenseigne))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "entites.Ressourceenseigne[ idressourceenseigne=" + idressourceenseigne + " ]";
    }
    
}

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package entites;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author Ernest
 */
@Entity
@Table(name = "ressources")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Ressources.findAll", query = "SELECT r FROM Ressources r"),
    @NamedQuery(name = "Ressources.findByIdressources", query = "SELECT r FROM Ressources r WHERE r.idressources = :idressources"),
    @NamedQuery(name = "Ressources.findByCoderessources", query = "SELECT r FROM Ressources r WHERE r.coderessources = :coderessources"),
    @NamedQuery(name = "Ressources.findByLibelleFr", query = "SELECT r FROM Ressources r WHERE r.libelleFr = :libelleFr"),
    @NamedQuery(name = "Ressources.findByLibelleEn", query = "SELECT r FROM Ressources r WHERE r.libelleEn = :libelleEn")})
public class Ressources implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "idressources")
    private Integer idressources;
    @Column(name = "coderessources")
    private String coderessources;
    @Column(name = "libelle_fr")
    private String libelleFr;
    @Column(name = "libelle_en")
    private String libelleEn;
    @Lob
    @Column(name = "description")
    private String description;

    public Ressources() {
    }

    public Ressources(Integer idressources) {
        this.idressources = idressources;
    }

    public Integer getIdressources() {
        return idressources;
    }

    public void setIdressources(Integer idressources) {
        this.idressources = idressources;
    }

    public String getCoderessources() {
        return coderessources;
    }

    public void setCoderessources(String coderessources) {
        this.coderessources = coderessources;
    }

    public String getLibelleFr() {
        return libelleFr;
    }

    public void setLibelleFr(String libelleFr) {
        this.libelleFr = libelleFr;
    }

    public String getLibelleEn() {
        return libelleEn;
    }

    public void setLibelleEn(String libelleEn) {
        this.libelleEn = libelleEn;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idressources != null ? idressources.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Ressources)) {
            return false;
        }
        Ressources other = (Ressources) object;
        if ((this.idressources == null && other.idressources != null) || (this.idressources != null && !this.idressources.equals(other.idressources))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "entites.Ressources[ idressources=" + idressources + " ]";
    }
    
}

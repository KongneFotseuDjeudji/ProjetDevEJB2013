/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package entites;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author Thierrynems
 */
@Entity
@Table(name = "etudiant")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Etudiant.findAll", query = "SELECT e FROM Etudiant e"),
    @NamedQuery(name = "Etudiant.findByIdEtudiant", query = "SELECT e FROM Etudiant e WHERE e.idEtudiant = :idEtudiant"),
    @NamedQuery(name = "Etudiant.findByIdusers", query = "SELECT e FROM Etudiant e WHERE e.idusers = :idusers"),
    @NamedQuery(name = "Etudiant.findByMatriculeetud", query = "SELECT e FROM Etudiant e WHERE e.matriculeetud = :matriculeetud"),
    @NamedQuery(name = "Etudiant.findByNometud", query = "SELECT e FROM Etudiant e WHERE e.nometud = :nometud"),
    @NamedQuery(name = "Etudiant.findByPrenometud", query = "SELECT e FROM Etudiant e WHERE e.prenometud = :prenometud"),
    @NamedQuery(name = "Etudiant.findByDatenaissetud", query = "SELECT e FROM Etudiant e WHERE e.datenaissetud = :datenaissetud"),
    @NamedQuery(name = "Etudiant.findByLieuNaissance", query = "SELECT e FROM Etudiant e WHERE e.lieuNaissance = :lieuNaissance"),
    @NamedQuery(name = "Etudiant.findByNationaliteetud", query = "SELECT e FROM Etudiant e WHERE e.nationaliteetud = :nationaliteetud"),
    @NamedQuery(name = "Etudiant.findBySexeetud", query = "SELECT e FROM Etudiant e WHERE e.sexeetud = :sexeetud"),
    @NamedQuery(name = "Etudiant.findByLangue", query = "SELECT e FROM Etudiant e WHERE e.langue = :langue"),
    @NamedQuery(name = "Etudiant.findByPhotoetud", query = "SELECT e FROM Etudiant e WHERE e.photoetud = :photoetud"),
    @NamedQuery(name = "Etudiant.findByDiplomeadmission", query = "SELECT e FROM Etudiant e WHERE e.diplomeadmission = :diplomeadmission"),
    @NamedQuery(name = "Etudiant.findByCnietud", query = "SELECT e FROM Etudiant e WHERE e.cnietud = :cnietud"),
    @NamedQuery(name = "Etudiant.findByDateinscription", query = "SELECT e FROM Etudiant e WHERE e.dateinscription = :dateinscription")})
public class Etudiant implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "idEtudiant")
    private Integer idEtudiant;
    @Basic(optional = false)
    @Column(name = "idusers")
    private int idusers;
    @Basic(optional = false)
    @Column(name = "matriculeetud")
    private String matriculeetud;
    @Basic(optional = false)
    @Column(name = "nometud")
    private String nometud;
    @Basic(optional = false)
    @Column(name = "prenometud")
    private String prenometud;
    @Basic(optional = false)
    @Column(name = "datenaissetud")
    @Temporal(TemporalType.DATE)
    private Date datenaissetud;
    @Basic(optional = false)
    @Column(name = "lieuNaissance")
    private String lieuNaissance;
    @Basic(optional = false)
    @Column(name = "nationaliteetud")
    private String nationaliteetud;
    @Basic(optional = false)
    @Column(name = "sexeetud")
    private String sexeetud;
    @Basic(optional = false)
    @Column(name = "langue")
    private String langue;
    @Basic(optional = false)
    @Column(name = "photoetud")
    private String photoetud;
    @Basic(optional = false)
    @Column(name = "diplomeadmission")
    private String diplomeadmission;
    @Basic(optional = false)
    @Column(name = "cnietud")
    private String cnietud;
    @Basic(optional = false)
    @Column(name = "dateinscription")
    @Temporal(TemporalType.DATE)
    private Date dateinscription;

    public Etudiant() {
    }

    public Etudiant(Integer idEtudiant) {
        this.idEtudiant = idEtudiant;
    }

    public Etudiant(Integer idEtudiant, int idusers, String matriculeetud, String nometud, String prenometud, Date datenaissetud, String lieuNaissance, String nationaliteetud, String sexeetud, String langue, String photoetud, String diplomeadmission, String cnietud, Date dateinscription) {
        this.idEtudiant = idEtudiant;
        this.idusers = idusers;
        this.matriculeetud = matriculeetud;
        this.nometud = nometud;
        this.prenometud = prenometud;
        this.datenaissetud = datenaissetud;
        this.lieuNaissance = lieuNaissance;
        this.nationaliteetud = nationaliteetud;
        this.sexeetud = sexeetud;
        this.langue = langue;
        this.photoetud = photoetud;
        this.diplomeadmission = diplomeadmission;
        this.cnietud = cnietud;
        this.dateinscription = dateinscription;
    }

    public Integer getIdEtudiant() {
        return idEtudiant;
    }

    public void setIdEtudiant(Integer idEtudiant) {
        this.idEtudiant = idEtudiant;
    }

    public int getIdusers() {
        return idusers;
    }

    public void setIdusers(int idusers) {
        this.idusers = idusers;
    }

    public String getMatriculeetud() {
        return matriculeetud;
    }

    public void setMatriculeetud(String matriculeetud) {
        this.matriculeetud = matriculeetud;
    }

    public String getNometud() {
        return nometud;
    }

    public void setNometud(String nometud) {
        this.nometud = nometud;
    }

    public String getPrenometud() {
        return prenometud;
    }

    public void setPrenometud(String prenometud) {
        this.prenometud = prenometud;
    }

    public Date getDatenaissetud() {
        return datenaissetud;
    }

    public void setDatenaissetud(Date datenaissetud) {
        this.datenaissetud = datenaissetud;
    }

    public String getLieuNaissance() {
        return lieuNaissance;
    }

    public void setLieuNaissance(String lieuNaissance) {
        this.lieuNaissance = lieuNaissance;
    }

    public String getNationaliteetud() {
        return nationaliteetud;
    }

    public void setNationaliteetud(String nationaliteetud) {
        this.nationaliteetud = nationaliteetud;
    }

    public String getSexeetud() {
        return sexeetud;
    }

    public void setSexeetud(String sexeetud) {
        this.sexeetud = sexeetud;
    }

    public String getLangue() {
        return langue;
    }

    public void setLangue(String langue) {
        this.langue = langue;
    }

    public String getPhotoetud() {
        return photoetud;
    }

    public void setPhotoetud(String photoetud) {
        this.photoetud = photoetud;
    }

    public String getDiplomeadmission() {
        return diplomeadmission;
    }

    public void setDiplomeadmission(String diplomeadmission) {
        this.diplomeadmission = diplomeadmission;
    }

    public String getCnietud() {
        return cnietud;
    }

    public void setCnietud(String cnietud) {
        this.cnietud = cnietud;
    }

    public Date getDateinscription() {
        return dateinscription;
    }

    public void setDateinscription(Date dateinscription) {
        this.dateinscription = dateinscription;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idEtudiant != null ? idEtudiant.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Etudiant)) {
            return false;
        }
        Etudiant other = (Etudiant) object;
        if ((this.idEtudiant == null && other.idEtudiant != null) || (this.idEtudiant != null && !this.idEtudiant.equals(other.idEtudiant))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "entites.Etudiant[ idEtudiant=" + idEtudiant + " ]";
    }
    
}

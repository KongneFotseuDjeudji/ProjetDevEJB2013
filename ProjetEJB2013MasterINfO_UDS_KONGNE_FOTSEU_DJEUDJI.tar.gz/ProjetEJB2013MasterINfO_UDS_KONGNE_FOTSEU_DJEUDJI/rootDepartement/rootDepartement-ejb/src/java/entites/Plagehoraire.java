/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package entites;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author Ernest
 */
@Entity
@Table(name = "plagehoraire")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Plagehoraire.findAll", query = "SELECT p FROM Plagehoraire p"),
    @NamedQuery(name = "Plagehoraire.findByIdplagehoraire", query = "SELECT p FROM Plagehoraire p WHERE p.idplagehoraire = :idplagehoraire"),
    @NamedQuery(name = "Plagehoraire.findByIdminuite", query = "SELECT p FROM Plagehoraire p WHERE p.idminuite = :idminuite"),
    @NamedQuery(name = "Plagehoraire.findByIdheure", query = "SELECT p FROM Plagehoraire p WHERE p.idheure = :idheure"),
    @NamedQuery(name = "Plagehoraire.findByCode", query = "SELECT p FROM Plagehoraire p WHERE p.code = :code"),
    @NamedQuery(name = "Plagehoraire.findByIdminuitefin", query = "SELECT p FROM Plagehoraire p WHERE p.idminuitefin = :idminuitefin"),
    @NamedQuery(name = "Plagehoraire.findByIdheurefin", query = "SELECT p FROM Plagehoraire p WHERE p.idheurefin = :idheurefin"),
    @NamedQuery(name = "Plagehoraire.findByDate", query = "SELECT p FROM Plagehoraire p WHERE p.date = :date")})
public class Plagehoraire implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "idplagehoraire")
    private Integer idplagehoraire;
    @Basic(optional = false)
    @Column(name = "idminuite")
    private int idminuite;
    @Basic(optional = false)
    @Column(name = "idheure")
    private int idheure;
    @Column(name = "code")
    private String code;
    @Column(name = "idminuitefin")
    private Integer idminuitefin;
    @Column(name = "idheurefin")
    private Integer idheurefin;
    @Column(name = "date")
    @Temporal(TemporalType.DATE)
    private Date date;

    public Plagehoraire() {
    }

    public Plagehoraire(Integer idplagehoraire) {
        this.idplagehoraire = idplagehoraire;
    }

    public Plagehoraire(Integer idplagehoraire, int idminuite, int idheure) {
        this.idplagehoraire = idplagehoraire;
        this.idminuite = idminuite;
        this.idheure = idheure;
    }

    public Integer getIdplagehoraire() {
        return idplagehoraire;
    }

    public void setIdplagehoraire(Integer idplagehoraire) {
        this.idplagehoraire = idplagehoraire;
    }

    public int getIdminuite() {
        return idminuite;
    }

    public void setIdminuite(int idminuite) {
        this.idminuite = idminuite;
    }

    public int getIdheure() {
        return idheure;
    }

    public void setIdheure(int idheure) {
        this.idheure = idheure;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public Integer getIdminuitefin() {
        return idminuitefin;
    }

    public void setIdminuitefin(Integer idminuitefin) {
        this.idminuitefin = idminuitefin;
    }

    public Integer getIdheurefin() {
        return idheurefin;
    }

    public void setIdheurefin(Integer idheurefin) {
        this.idheurefin = idheurefin;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idplagehoraire != null ? idplagehoraire.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Plagehoraire)) {
            return false;
        }
        Plagehoraire other = (Plagehoraire) object;
        if ((this.idplagehoraire == null && other.idplagehoraire != null) || (this.idplagehoraire != null && !this.idplagehoraire.equals(other.idplagehoraire))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "entites.Plagehoraire[ idplagehoraire=" + idplagehoraire + " ]";
    }
    
}

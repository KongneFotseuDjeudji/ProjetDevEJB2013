/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package entites;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author Ernest
 */
@Entity
@Table(name = "ueprogramme")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Ueprogramme.findAll", query = "SELECT u FROM Ueprogramme u"),
    @NamedQuery(name = "Ueprogramme.findByIdueprogramme", query = "SELECT u FROM Ueprogramme u WHERE u.idueprogramme = :idueprogramme"),
    @NamedQuery(name = "Ueprogramme.findByIdue", query = "SELECT u FROM Ueprogramme u WHERE u.idue = :idue"),
    @NamedQuery(name = "Ueprogramme.findByIdProgramme", query = "SELECT u FROM Ueprogramme u WHERE u.idProgramme = :idProgramme"),
    @NamedQuery(name = "Ueprogramme.findByTypeue", query = "SELECT u FROM Ueprogramme u WHERE u.typeue = :typeue")})
public class Ueprogramme implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "idueprogramme")
    private Integer idueprogramme;
    @Basic(optional = false)
    @Column(name = "idue")
    private int idue;
    @Basic(optional = false)
    @Column(name = "idProgramme")
    private int idProgramme;
    @Basic(optional = false)
    @Column(name = "typeue")
    private String typeue;

    public Ueprogramme() {
    }

    public Ueprogramme(Integer idueprogramme) {
        this.idueprogramme = idueprogramme;
    }

    public Ueprogramme(Integer idueprogramme, int idue, int idProgramme, String typeue) {
        this.idueprogramme = idueprogramme;
        this.idue = idue;
        this.idProgramme = idProgramme;
        this.typeue = typeue;
    }

    public Integer getIdueprogramme() {
        return idueprogramme;
    }

    public void setIdueprogramme(Integer idueprogramme) {
        this.idueprogramme = idueprogramme;
    }

    public int getIdue() {
        return idue;
    }

    public void setIdue(int idue) {
        this.idue = idue;
    }

    public int getIdProgramme() {
        return idProgramme;
    }

    public void setIdProgramme(int idProgramme) {
        this.idProgramme = idProgramme;
    }

    public String getTypeue() {
        return typeue;
    }

    public void setTypeue(String typeue) {
        this.typeue = typeue;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idueprogramme != null ? idueprogramme.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Ueprogramme)) {
            return false;
        }
        Ueprogramme other = (Ueprogramme) object;
        if ((this.idueprogramme == null && other.idueprogramme != null) || (this.idueprogramme != null && !this.idueprogramme.equals(other.idueprogramme))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "entites.Ueprogramme[ idueprogramme=" + idueprogramme + " ]";
    }
    
}

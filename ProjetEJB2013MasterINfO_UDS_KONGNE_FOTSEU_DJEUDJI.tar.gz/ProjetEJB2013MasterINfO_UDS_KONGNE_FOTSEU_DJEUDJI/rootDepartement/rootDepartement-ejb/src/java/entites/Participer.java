/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package entites;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author Ernest
 */
@Entity
@Table(name = "participer")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Participer.findAll", query = "SELECT p FROM Participer p"),
    @NamedQuery(name = "Participer.findByIdParticiper", query = "SELECT p FROM Participer p WHERE p.idParticiper = :idParticiper"),
    @NamedQuery(name = "Participer.findByIdEtudiant", query = "SELECT p FROM Participer p WHERE p.idEtudiant = :idEtudiant"),
    @NamedQuery(name = "Participer.findByIdEnseigner", query = "SELECT p FROM Participer p WHERE p.idEnseigner = :idEnseigner"),
    @NamedQuery(name = "Participer.findByCodeparticiper", query = "SELECT p FROM Participer p WHERE p.codeparticiper = :codeparticiper")})
public class Participer implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "idParticiper")
    private Integer idParticiper;
    @Basic(optional = false)
    @Column(name = "idEtudiant")
    private int idEtudiant;
    @Basic(optional = false)
    @Column(name = "idEnseigner")
    private int idEnseigner;
    @Basic(optional = false)
    @Column(name = "codeparticiper")
    private String codeparticiper;

    public Participer() {
    }

    public Participer(Integer idParticiper) {
        this.idParticiper = idParticiper;
    }

    public Participer(Integer idParticiper, int idEtudiant, int idEnseigner, String codeparticiper) {
        this.idParticiper = idParticiper;
        this.idEtudiant = idEtudiant;
        this.idEnseigner = idEnseigner;
        this.codeparticiper = codeparticiper;
    }

    public Integer getIdParticiper() {
        return idParticiper;
    }

    public void setIdParticiper(Integer idParticiper) {
        this.idParticiper = idParticiper;
    }

    public int getIdEtudiant() {
        return idEtudiant;
    }

    public void setIdEtudiant(int idEtudiant) {
        this.idEtudiant = idEtudiant;
    }

    public int getIdEnseigner() {
        return idEnseigner;
    }

    public void setIdEnseigner(int idEnseigner) {
        this.idEnseigner = idEnseigner;
    }

    public String getCodeparticiper() {
        return codeparticiper;
    }

    public void setCodeparticiper(String codeparticiper) {
        this.codeparticiper = codeparticiper;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idParticiper != null ? idParticiper.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Participer)) {
            return false;
        }
        Participer other = (Participer) object;
        if ((this.idParticiper == null && other.idParticiper != null) || (this.idParticiper != null && !this.idParticiper.equals(other.idParticiper))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "entites.Participer[ idParticiper=" + idParticiper + " ]";
    }
    
}

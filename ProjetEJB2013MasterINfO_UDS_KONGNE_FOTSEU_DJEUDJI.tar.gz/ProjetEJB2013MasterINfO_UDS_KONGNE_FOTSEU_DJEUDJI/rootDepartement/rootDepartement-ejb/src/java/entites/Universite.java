/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package entites;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author Ernest
 */
@Entity
@Table(name = "universite")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Universite.findAll", query = "SELECT u FROM Universite u"),
    @NamedQuery(name = "Universite.findByIdUniversite", query = "SELECT u FROM Universite u WHERE u.idUniversite = :idUniversite"),
    @NamedQuery(name = "Universite.findByCodeuniversite", query = "SELECT u FROM Universite u WHERE u.codeuniversite = :codeuniversite"),
    @NamedQuery(name = "Universite.findByLibelleFr", query = "SELECT u FROM Universite u WHERE u.libelleFr = :libelleFr"),
    @NamedQuery(name = "Universite.findByLibelleEn", query = "SELECT u FROM Universite u WHERE u.libelleEn = :libelleEn"),
    @NamedQuery(name = "Universite.findByLogo", query = "SELECT u FROM Universite u WHERE u.logo = :logo"),
    @NamedQuery(name = "Universite.findByEmail", query = "SELECT u FROM Universite u WHERE u.email = :email"),
    @NamedQuery(name = "Universite.findByBoitepostale", query = "SELECT u FROM Universite u WHERE u.boitepostale = :boitepostale"),
    @NamedQuery(name = "Universite.findByTelephone", query = "SELECT u FROM Universite u WHERE u.telephone = :telephone"),
    @NamedQuery(name = "Universite.findBySiteweb", query = "SELECT u FROM Universite u WHERE u.siteweb = :siteweb"),
    @NamedQuery(name = "Universite.findByUnivcourante", query = "SELECT u FROM Universite u WHERE u.univcourante = :univcourante")})
public class Universite implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "idUniversite")
    private Integer idUniversite;
    @Basic(optional = false)
    @Column(name = "codeuniversite")
    private String codeuniversite;
    @Basic(optional = false)
    @Column(name = "libelle_fr")
    private String libelleFr;
    @Basic(optional = false)
    @Column(name = "libelle_en")
    private String libelleEn;
    @Basic(optional = false)
    @Column(name = "logo")
    private String logo;
    @Basic(optional = false)
    @Column(name = "email")
    private String email;
    @Basic(optional = false)
    @Column(name = "boitepostale")
    private String boitepostale;
    @Basic(optional = false)
    @Column(name = "telephone")
    private String telephone;
    @Basic(optional = false)
    @Column(name = "siteweb")
    private String siteweb;
    @Basic(optional = false)
    @Column(name = "univcourante")
    private boolean univcourante;

    public Universite() {
    }

    public Universite(Integer idUniversite) {
        this.idUniversite = idUniversite;
    }

    public Universite(Integer idUniversite, String codeuniversite, String libelleFr, String libelleEn, String logo, String email, String boitepostale, String telephone, String siteweb, boolean univcourante) {
        this.idUniversite = idUniversite;
        this.codeuniversite = codeuniversite;
        this.libelleFr = libelleFr;
        this.libelleEn = libelleEn;
        this.logo = logo;
        this.email = email;
        this.boitepostale = boitepostale;
        this.telephone = telephone;
        this.siteweb = siteweb;
        this.univcourante = univcourante;
    }

    public Integer getIdUniversite() {
        return idUniversite;
    }

    public void setIdUniversite(Integer idUniversite) {
        this.idUniversite = idUniversite;
    }

    public String getCodeuniversite() {
        return codeuniversite;
    }

    public void setCodeuniversite(String codeuniversite) {
        this.codeuniversite = codeuniversite;
    }

    public String getLibelleFr() {
        return libelleFr;
    }

    public void setLibelleFr(String libelleFr) {
        this.libelleFr = libelleFr;
    }

    public String getLibelleEn() {
        return libelleEn;
    }

    public void setLibelleEn(String libelleEn) {
        this.libelleEn = libelleEn;
    }

    public String getLogo() {
        return logo;
    }

    public void setLogo(String logo) {
        this.logo = logo;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getBoitepostale() {
        return boitepostale;
    }

    public void setBoitepostale(String boitepostale) {
        this.boitepostale = boitepostale;
    }

    public String getTelephone() {
        return telephone;
    }

    public void setTelephone(String telephone) {
        this.telephone = telephone;
    }

    public String getSiteweb() {
        return siteweb;
    }

    public void setSiteweb(String siteweb) {
        this.siteweb = siteweb;
    }

    public boolean getUnivcourante() {
        return univcourante;
    }

    public void setUnivcourante(boolean univcourante) {
        this.univcourante = univcourante;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idUniversite != null ? idUniversite.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Universite)) {
            return false;
        }
        Universite other = (Universite) object;
        if ((this.idUniversite == null && other.idUniversite != null) || (this.idUniversite != null && !this.idUniversite.equals(other.idUniversite))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "entites.Universite[ idUniversite=" + idUniversite + " ]";
    }
    
}

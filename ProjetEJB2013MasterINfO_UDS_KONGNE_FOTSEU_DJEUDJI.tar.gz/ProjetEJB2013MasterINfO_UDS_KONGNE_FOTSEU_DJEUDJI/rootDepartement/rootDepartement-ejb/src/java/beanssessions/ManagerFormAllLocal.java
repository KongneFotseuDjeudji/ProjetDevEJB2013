/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package beanssessions;

import entites.Annee;
import entites.Classe;
import entites.Cursus;
import entites.Departement;
import entites.Enseignant;
import entites.Enseigner;
import entites.Etudiant;
import entites.Evaluation;
import entites.Heure;
import entites.Matiere;
import entites.Minuite;
import entites.Noteevaluation;
import entites.Options;
import entites.Plagehoraire;
import entites.Salle;
import entites.Semestre;
import entites.Session;
import java.util.Collection;
import java.util.Date;
import java.util.List;
import javax.ejb.Remote;

/**
 *
 * @author Thierrynems
 */
@Remote
public interface ManagerFormAllLocal {

     public Collection<Annee> SelectAnnee();

    public Collection<Cursus> SelectCursus();

    public Collection<Options> SelectOption();

    public Collection<Classe> SelectClasse();

    public Collection<Etudiant> SelectListeEtudiant();
    
    public boolean insertEtudiant(String nometud, String prenometud, Date datenaissetud, String lieuNaissance, String nationaliteetud, String sexeetud, String langue, String photoetud, String diplomeadmission, String cnietud, int idclasse, int idannee, int idoptions, int idcursus);

    public Boolean InsertSession(Session ses);

    public Collection<Session> SelectListeSession();

    public Collection<Session> SelectSessionByAnnee(int idannee);

    public Collection<Departement> SelectDepartement();

    public Collection<Semestre> SelectSemestre();

    public Collection<Options> SelectOptionsByCursus(int idcursus);

    public List<Matiere> SelectMatiereProg(int idoptionsemestre, int idsession); 

    public Boolean InsertEval(Evaluation e);

    public Collection<Evaluation> SelectEval(int idoptionsemestre, int idMatiere, int idSession, int idtypeevaluation);

    public Collection<Etudiant> SelectEtudInscrit(int idclasse, int idannee, int idoptions);

    public Classe SelectClasseByidSemestre(int idsemestre);

    public Boolean saveEval(int idEtudiant, int idoptionsemestre, int idSession, int idMatiere, int idevaluation, int idoptions, String valeur, int type);

    public Noteevaluation findNoteEval(int idEtudiant, int idoptionsemestre, int idSession, int idMatiere, int idevaluation, int idoptions);

    public Boolean findAnoEval(int idsemestre,int idMatiere,int idoptions,int idSession,String anonymat);

    public Collection<Noteevaluation> findAnonymatEval(int idoptionsemestre, int idSession, int idMatiere,int idoptions);

    public Collection<Matiere> getMatiereProgAdopte(int idannee, int idoptions, int idsemestre);

    public Collection<Enseignant> getListEnseignant();

    public Collection<Salle> getListSalle();

    public Collection<Plagehoraire> getListHoraire();

    public boolean IsExisteHoraire(int idhoraire, String datej);

    public void saveEntitie(Object o);

    public Minuite getMinuiteById(int idminuite);

    public Heure getHeureById(int idheure);

    public Collection<Enseigner> getDateEnseigne(int idsession, int idsemestre);

    public Collection<Enseigner> getEnseigne(int idsession, int idsemestre,String datedebut,String datefin);

    public Salle getSalleById(int idsalle);

    public Matiere getMatiereById(int idmatiere);

    public Enseignant getEnseignantById(int idenseignant);

    public Plagehoraire getPlageHoraireById(int idplage);

    public Enseigner getEnseigneAll(int idplage, String date);
    
}

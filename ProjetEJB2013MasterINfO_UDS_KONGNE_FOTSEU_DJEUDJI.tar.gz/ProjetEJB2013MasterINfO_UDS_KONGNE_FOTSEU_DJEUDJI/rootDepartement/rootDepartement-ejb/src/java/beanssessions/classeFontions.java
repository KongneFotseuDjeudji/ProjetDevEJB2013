/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package beanssessions;

import entites.Annee;
import entites.Cursus;
import entites.Departement;
import entites.Enseignant;
import entites.Etudiant;
import entites.Heure;
import entites.Matiere;
import entites.Matiereprogrammee;
import entites.Matiereue;
import entites.Minuite;
import entites.Noteevaluation;
import entites.Options;
import entites.Plagehoraire;
import entites.Programme;
import entites.Programmeadopte;
import entites.Ressources;
import entites.Salle;
import entites.Semestre;
import entites.Session;
import entites.Surveillant;
import entites.Ue;
import etats.EtatMatiereue;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

/**
 *
 * @author Ernest
 */
@Stateless(mappedName = "accesDataBean")
public class classeFontions implements classeFonctionsLocal {

    @PersistenceContext(unitName = "rootDepartement-ejbPU")
    private EntityManager ema;
    // Add business logic below. (Right-click in editor and choose
    // "Insert Code > Add Business Method")

    /*
     * Fonction permettant de retourner
     * la liste des departements
     */
    @Override
    public Collection<Departement> getListDepartement() {
        try {
            Query query = ema.createNamedQuery("Departement.findAll");
            Collection<Departement> lt = query.getResultList();
            return lt;
        } catch (NoResultException e) {
            Departement dept = new Departement();
            dept.setLibelleEn(null);
            dept.setCode(null);
            dept.setLibelleFr(null);
            System.out.println("Noresult Exception generer=" + e.getMessage());
            return (Collection<Departement>) dept;
        } catch (NullPointerException e) {
            Departement dept = new Departement();
            dept.setLibelleEn(null);
            dept.setCode(null);
            dept.setLibelleFr(null);
            System.out.println("NullPointerException generer=" + e.getMessage());
            return (Collection<Departement>) dept;
        }
    }

    /*
     * Fonction permettant de retourner 
     * la liste des enseignants
     */
    @Override
    public Collection<Enseignant> getListEnseignant() {
        try {
            Query query = ema.createNamedQuery("Enseignant.findAll");
            Collection<Enseignant> lt = query.getResultList();
            return lt;
        } catch (NoResultException e) {
            Enseignant ens = new Enseignant();
            ens.setNomenseig(null);
            ens.setCategorieenseig(null);
            ens.setCodeenseignant(null);
            System.out.println("Noresult Exception generer=" + e.getMessage());
            return (Collection<Enseignant>) ens;
        } catch (NullPointerException e) {
            Enseignant ens = new Enseignant();
            ens.setNomenseig(null);
            ens.setCategorieenseig(null);
            ens.setCodeenseignant(null);
            System.out.println("NullPointerException generer=" + e.getMessage());
            return (Collection<Enseignant>) ens;
        }
    }//-----fin de fonction getListEnseignant
    /*
     * Fonction de retour de la liste 
     * des salles.
     */

    @Override
    public Collection<Salle> getListSalle() {
        try {
            Query query = ema.createNamedQuery("Salle.findAll");
            Collection<Salle> sa = query.getResultList();
            return sa;
        } catch (NoResultException e) {
            Salle sa = new Salle();
            sa.setCapacite(null);
            sa.setCodesalle(null);
            sa.setLibelleFr(null);
            System.out.println("Noresult Exception generer=" + e.getMessage());
            return (Collection<Salle>) sa;
        } catch (NullPointerException e) {
            Salle sa = new Salle();
            sa.setCapacite(null);
            sa.setCodesalle(null);
            sa.setLibelleFr(null);
            System.out.println("NullPointerException generer=" + e.getMessage());
            return (Collection<Salle>) sa;
        }
    }//----fin de fonction getListSalle
    /*
     * fonction de retour de la liste
     * des plages horaires enregistrées
     */

    @Override
    public Collection<Plagehoraire> getListPlage() {
        try {
            Query query = ema.createNamedQuery("Plagehoraire.findAll");
            Collection<Plagehoraire> pl = query.getResultList();
            return pl;
        } catch (NoResultException e) {
            Plagehoraire pl = new Plagehoraire();
            pl.setCode(null);
            pl.setDate(null);
            pl.setIdheurefin(null);
            System.out.println("Noresult Exception generer=" + e.getMessage());
            return (Collection<Plagehoraire>) pl;
        } catch (NullPointerException e) {
            Plagehoraire pl = new Plagehoraire();
            pl.setCode(null);
            pl.setDate(null);
            pl.setIdheurefin(null);
            System.out.println("NullPointerException generer=" + e.getMessage());
            return (Collection<Plagehoraire>) pl;
        }
    }
    
    /*
     * fonction permettant de retourner
     * la liste des heures
     */

    @Override
    public Collection<Heure> getListHeure() {
        try {
            Query query = ema.createNamedQuery("Heure.findAll");
            Collection<Heure> pl = query.getResultList();
            return pl;
        } catch (NoResultException e) {
            Heure pl = new Heure();
            pl.setCode(null);
            pl.setLibelleEn(null);
            pl.setLibelleFr(null);
            System.out.println("Noresult Exception generer=" + e.getMessage());
            return (Collection<Heure>) pl;
        } catch (NullPointerException e) {
            Heure pl = new Heure();
            pl.setCode(null);
            pl.setLibelleEn(null);
            pl.setLibelleFr(null);
            System.out.println("NullPointerException generer=" + e.getMessage());
            return (Collection<Heure>) pl;
        }
    }
    /*
     * fonction permettant de retourner
     * la liste des minutes
     */

    @Override
    public Collection<Minuite> getListMinute() {
        try {
            Query query = ema.createNamedQuery("Minuite.findAll");
            Collection<Minuite> pl = query.getResultList();
            return pl;
        } catch (NoResultException e) {
            Minuite pl = new Minuite();
            pl.setCode(null);
            pl.setLibelleEn(null);
            pl.setLibelleFr(null);
            System.out.println("Noresult Exception generer=" + e.getMessage());
            return (Collection<Minuite>) pl;
        } catch (NullPointerException e) {
            Minuite pl = new Minuite();
            pl.setCode(null);
            pl.setLibelleEn(null);
            pl.setLibelleFr(null);
            System.out.println("NullPointerException generer=" + e.getMessage());
            return (Collection<Minuite>) pl;
        }
    }
    
    /*
     * fonction de retour de
     * la liste des surveillants
     */
    @Override
    public Collection<Surveillant> getListSurveillant() {
        try {
            Query query = ema.createNamedQuery("Surveillant.findAll");
            Collection<Surveillant> pl = query.getResultList();
            return pl;
        } catch (NoResultException e) {
            Surveillant pl = new Surveillant();
            pl.setCodesurveillant(null);
            pl.setNomsurveillant(null);
            pl.setPrenomsurveillant(null);
            System.out.println("Noresult Exception generer=" + e.getMessage());
            return (Collection<Surveillant>) pl;
        } catch (NullPointerException e) {
            Surveillant pl = new Surveillant();
            pl.setCodesurveillant(null);
            pl.setNomsurveillant(null);
            pl.setPrenomsurveillant(null);
            System.out.println("NullPointerException generer=" + e.getMessage());
            return (Collection<Surveillant>) pl;
        }
    }

    @Override
    public Collection<Ressources> getListRessources() {
        try {
            Query query = ema.createNamedQuery("Ressources.findAll");
            Collection<Ressources> pl = query.getResultList();
            return pl;
        } catch (NoResultException e) {
            Ressources pl = new Ressources();
            pl.setCoderessources(null);
            pl.setDescription(null);
            pl.setLibelleEn(null);
            System.out.println("Noresult Exception generer=" + e.getMessage());
            return (Collection<Ressources>) pl;
        } catch (NullPointerException e) {
             Ressources pl = new Ressources();
            pl.setCoderessources(null);
            pl.setDescription(null);
            pl.setLibelleEn(null);
            System.out.println("NullPointerException generer=" + e.getMessage());
            return (Collection<Ressources>) pl;
        }
    }
    
    //-----retourne la liste des annees academiques------
    @Override
    public Collection<Annee> getListAnnee() {
        try {
            Query query = ema.createNamedQuery("Annee.findAll");
            Collection<Annee> pl = query.getResultList();
            return pl;
        } catch (NoResultException e) {
            Annee pl = new Annee();
            pl.setCode(null);
            pl.setLibelleFr(null);
            pl.setLibelleEn(null);
            System.out.println("Noresult Exception generer=" + e.getMessage());
            return (Collection<Annee>) pl;
        } catch (NullPointerException e) {
            Annee pl = new Annee();
            pl.setCode(null);
            pl.setLibelleFr(null);
            pl.setLibelleEn(null);
            System.out.println("NullPointerException generer=" + e.getMessage());
            return (Collection<Annee>) pl;
        }
    }
    
    //-----retourne les cursus d'un departement------    
    @Override
    public Collection<Cursus> getListCursus(int iddepartement) {
        try {
            Query query = ema.createNamedQuery("Cursus.findByIddepartement");
            query.setParameter("iddepartement", iddepartement);
            Collection<Cursus> pl = query.getResultList();
            return pl;
        } catch (NoResultException e) {
            Cursus pl = new Cursus();
            pl.setCodecursus(null);
            pl.setLibelleFr(null);
            System.out.println("Noresult Exception generer=" + e.getMessage());
            return (Collection<Cursus>) pl;
        } catch (NullPointerException e) {
           Cursus pl = new Cursus();
            pl.setCodecursus(null);
            pl.setLibelleFr(null);
            System.out.println("NullPointerException generer=" + e.getMessage());
            return (Collection<Cursus>) pl;
        }
    }
    
    //------fonction permetant de reourner les options d'un cursus---
    @Override
    public Collection<Options> getListOptions(int idcursus) {
        try {
            Query query = ema.createNamedQuery("Options.findByIdCursus");
            query.setParameter("idCursus", idcursus);
            Collection<Options> pl = query.getResultList();
            return pl;
        } catch (NoResultException e) {
            Options pl = new Options();
            pl.setCodeoption(null);
            pl.setLibelleFr(null);
            System.out.println("Noresult Exception generer=" + e.getMessage());
            return (Collection<Options>) pl;
        } catch (NullPointerException e) {
           Options pl = new Options();
            pl.setCodeoption(null);
            pl.setLibelleFr(null);
            System.out.println("NullPointerException generer=" + e.getMessage());
            return (Collection<Options>) pl;
        }
    }
 //---fonction permettant de retourner la liste des semestres---
    @Override
    public Collection<Semestre> getListSemestre() {
        try {
            Query query = ema.createNamedQuery("Semestre.findAll");
            Collection<Semestre> pl = query.getResultList();
            return pl;
        } catch (NoResultException e) {
            Semestre pl = new Semestre();
            pl.setCode(null);
            pl.setLibelleFr(null);
            System.out.println("Noresult Exception generer=" + e.getMessage());
            return (Collection<Semestre>) pl;
        } catch (NullPointerException e) {
           Semestre pl = new Semestre();
            pl.setCode(null);
            pl.setLibelleFr(null);
            System.out.println("NullPointerException generer=" + e.getMessage());
            return (Collection<Semestre>) pl;
        }
    }
    
    //---fonction permettant de retourner la liste des semestres---
    @Override
    public Collection<Programme> getListProgramme() {
        try {
            Query query = ema.createNamedQuery("Programme.findAll");
            Collection<Programme> pl = query.getResultList();
            return pl;
        } catch (NoResultException e) {
            Programme pl = new Programme();
            pl.setCodeprogramme(null);
            pl.setLibelleFr(null);
            System.out.println("Noresult Exception generer=" + e.getMessage());
            return (Collection<Programme>) pl;
        } catch (NullPointerException e) {
            Programme pl = new Programme();
            pl.setCodeprogramme(null);
            pl.setLibelleFr(null);
            System.out.println("NullPointerException generer=" + e.getMessage());
            return (Collection<Programme>) pl;
        }
    }
    
    //---fonction permettant de retourner la liste des semestres---
    @Override
    public Collection<Session> getListSession(int idannee) {
        try {
            Query query = ema.createNamedQuery("Session.findByIdannee");
            query.setParameter("idannee", idannee);
            Collection<Session> pl = query.getResultList();
            return pl;
        } catch (NoResultException e) {
            Session pl = new Session();
            pl.setCodesession(null);
            pl.setLibelleFr(null);
            System.out.println("Noresult Exception generer=" + e.getMessage());
            return (Collection<Session>) pl;
        } catch (NullPointerException e) {
            Session pl = new Session();
            pl.setCodesession(null);
            pl.setLibelleFr(null);
            System.out.println("NullPointerException generer=" + e.getMessage());
            return (Collection<Session>) pl;
        }
    }
    
    //---fonction permettant de retourner la liste des programmes adoptés---
    @Override
    public Collection<Programmeadopte> getListProgrammeadopte() {
        try {
            Query query = ema.createNamedQuery("Programmeadopte.findAll");
            Collection<Programmeadopte> pl = query.getResultList();
            return pl;
        } catch (NoResultException e) {
            Programmeadopte pl = new Programmeadopte();
            System.out.println("Noresult Exception generer=" + e.getMessage());
            return (Collection<Programmeadopte>) pl;
        } catch (NullPointerException e) {
            Programmeadopte pl = new Programmeadopte();
            System.out.println("NullPointerException generer=" + e.getMessage());
            return (Collection<Programmeadopte>) pl;
        }
    }
    
    //------fonction permetant de reourner les info d'une options donnée---
    @Override
    public Collection<Options> getOptionsByIdoption(int idOption) {
        try {
            Query query = ema.createNamedQuery("Options.findByIdoptions");
            query.setParameter("idoptions", idOption);
            Collection<Options> pl = query.getResultList();
            return pl;
        } catch (NoResultException e) {
            Options pl = new Options();
            pl.setCodeoption(null);
            pl.setLibelleFr(null);
            System.out.println("Noresult Exception generer=" + e.getMessage());
            return (Collection<Options>) pl;
        } catch (NullPointerException e) {
           Options pl = new Options();
            pl.setCodeoption(null);
            pl.setLibelleFr(null);
            System.out.println("NullPointerException generer=" + e.getMessage());
            return (Collection<Options>) pl;
        }
    }
/*
 * fonction permettant de retourner 
 * le programmes adopté pour une option 
 * pour un semestre
 * d'une année academique
 */
    @Override
    public Collection<Programme> getProgrammeadopte(int idAnnee,int idOptions,int idSemestre) {
        String sql="SELECT p.* FROM programme p JOIN programmeadopte pa ON p.idProgramme=pa.idProgramme WHERE pa.idannee='"+idAnnee+"' AND pa.idoptions='"+idOptions+"' AND pa.idsemestre='"+idSemestre+"'";
        try{
            Query query = ema.createNativeQuery(sql,Programme.class);
            Collection<Programme> pl = query.getResultList();
            return pl;
        } catch (NoResultException e) {
            Programme pl = new Programme();
            System.out.println("Noresult Exception generer=" + e.getMessage());
            return (Collection<Programme>) pl;
        } catch (NullPointerException e) {
            Programme pl = new Programme();
            System.out.println("NullPointerException generer=" + e.getMessage());
            return (Collection<Programme>) pl;
        }
    }

/*
 * fonction permettant de retourner 
 * les UE d'un programme
 */
    @Override
    public Collection<Ue> getListUEProgramme(int idProgramme) {
        String sql="SELECT u.* FROM ue u JOIN ueprogramme up ON u.idue=up.idue WHERE up.idProgramme='"+idProgramme+"'";
        try{
            Query query = ema.createNativeQuery(sql,Ue.class);
            Collection<Ue> pl = query.getResultList();
            return pl;
        } catch (NoResultException e) {
            Ue pl = new Ue();
            System.out.println("Noresult Exception generer=" + e.getMessage());
            return (Collection<Ue>) pl;
        } catch (NullPointerException e) {
            Ue pl = new Ue();
            System.out.println("NullPointerException generer=" + e.getMessage());
            return (Collection<Ue>) pl;
        }
    }

/*
 * fonction permettant de retourner 
 * les matieres de l'UE d'un programme
 */
    @Override
    public Collection<Matiereue> getListMatiereUE(int idUE) {
        String sql="SELECT me.* FROM matiereue me JOIN ue u ON u.idue=me.idue WHERE me.idue='"+idUE+"'";
        try{
            Query query = ema.createNativeQuery(sql,Matiereue.class);
            Collection<Matiereue> pl = query.getResultList();
            return pl;
        } catch (NoResultException e) {
            EtatMatiereue pl = new EtatMatiereue();
            System.out.println("Noresult Exception generer=" + e.getMessage());
            return (Collection<Matiereue>) pl;
        } catch (NullPointerException e) {
            EtatMatiereue pl = new EtatMatiereue();
            System.out.println("NullPointerException generer=" + e.getMessage());
            return (Collection<Matiereue>) pl;
        }
    }
    
 /*
 * fonction permettant de retourner 
 * les matieres de l'UE d'un programme
 */
    @Override
    public Matiere getMatiereId(int idMatiere) {
        try{
            Query query = ema.createNamedQuery("Matiere.findByIdMatiere");
            query.setParameter("idMatiere", idMatiere);
            Matiere pl = (Matiere)query.getSingleResult();
            return pl;
        } catch (NoResultException e) {
            Matiere pl = new Matiere();
            System.out.println("Noresult Exception generer=" + e.getMessage());
            return (Matiere) pl;
        } catch (NullPointerException e) {
            Matiere pl = new Matiere();
            System.out.println("NullPointerException generer=" + e.getMessage());
            return (Matiere) pl;
        }
    }
    
    /*
 * fonction permettant de retourner 
 * une annee a partie de son id
 */
    @Override
    public Annee getAnneeById(int idannee) {
        try{
            Query query = ema.createNamedQuery("Annee.findByIdannee");
            query.setParameter("idannee", idannee);
            Annee pl = (Annee)query.getSingleResult();
            return pl;
        } catch (NoResultException e) {
            Annee pl = new Annee();
            System.out.println("Noresult Exception generer=" + e.getMessage());
            return (Annee) pl;
        } catch (NullPointerException e) {
            Annee pl = new Annee();
            System.out.println("NullPointerException generer=" + e.getMessage());
            return (Annee) pl;
        }
    }
 /*
 * fonction permettant de retourner 
 * un departement a partie de son id
 */
    @Override
    public Departement getDepartementById(int iddepartement) {
        try{
            Query query = ema.createNamedQuery("Departement.findByIddepartement");
            query.setParameter("iddepartement", iddepartement);
            Departement pl = (Departement)query.getSingleResult();
            return pl;
        } catch (NoResultException e) {
            Departement pl = new Departement();
            System.out.println("Noresult Exception generer=" + e.getMessage());
            return (Departement) pl;
        } catch (NullPointerException e) {
            Departement pl = new Departement();
            System.out.println("NullPointerException generer=" + e.getMessage());
            return (Departement) pl;
        }
    }
    /*
 * fonction permettant de retourner 
 * un cursus a partie de son id
 */
    @Override
    public Cursus getCursusById(int idcursus) {
        try{
            Query query = ema.createNamedQuery("Cursus.findByIdCursus");
            query.setParameter("idCursus", idcursus);
            Cursus pl = (Cursus)query.getSingleResult();
            return pl;
        } catch (NoResultException e) {
            Cursus pl = new Cursus();
            System.out.println("Noresult Exception generer=" + e.getMessage());
            return (Cursus) pl;
        } catch (NullPointerException e) {
            Cursus pl = new Cursus();
            System.out.println("NullPointerException generer=" + e.getMessage());
            return (Cursus) pl;
        }
    }
    /*
 * fonction permettant de retourner 
 * une option a partie de son id
 */
    @Override
    public Options getOptionById(int idoptions) {
        try{
            Query query = ema.createNamedQuery("Options.findByIdoptions");
            query.setParameter("idoptions", idoptions);
            Options pl = (Options)query.getSingleResult();
            return pl;
        } catch (NoResultException e) {
            Options pl = new Options();
            System.out.println("Noresult Exception generer=" + e.getMessage());
            return (Options) pl;
        } catch (NullPointerException e) {
            Options pl = new Options();
            System.out.println("NullPointerException generer=" + e.getMessage());
            return (Options) pl;
        }
    }
    /*
 * fonction permettant de retourner 
 * un semestre a partie de son id
 */
    @Override
    public Semestre getSemestreById(int idSemestre) {
        try{
            Query query = ema.createNamedQuery("Semestre.findByIdSemestre");
            query.setParameter("idSemestre", idSemestre);
            Semestre pl = (Semestre)query.getSingleResult();
            return pl;
        } catch (NoResultException e) {
            Semestre pl = new Semestre();
            System.out.println("Noresult Exception generer=" + e.getMessage());
            return (Semestre) pl;
        } catch (NullPointerException e) {
            Semestre pl = new Semestre();
            System.out.println("NullPointerException generer=" + e.getMessage());
            return (Semestre) pl;
        }
    }
     /*
 * fonction permettant de retourner 
 * une session a partie de son id
 */
    @Override
    public Session getSessionById(int idSession) {
        try{
            Query query = ema.createNamedQuery("Session.findByIdSession");
            query.setParameter("idSession", idSession);
            Session pl = (Session)query.getSingleResult();
            return pl;
        } catch (NoResultException e) {
            Session pl = new Session();
            System.out.println("Noresult Exception generer=" + e.getMessage());
            return (Session) pl;
        } catch (NullPointerException e) {
            Session pl = new Session();
            System.out.println("NullPointerException generer=" + e.getMessage());
            return (Session) pl;
        }
    }
    
   //---fonction permettant de retourner la liste des semestres---
    @Override
    public Collection<Semestre> getSemestreByClasse(String classe) {
        try {
            Query query = ema.createNamedQuery("Semestre.findByClasse");
            query.setParameter("classe", classe);
            Collection<Semestre> pl = query.getResultList();
            return pl;
        } catch (NoResultException e) {
            Semestre pl = new Semestre();
            pl.setCode(null);
            pl.setLibelleFr(null);
            System.out.println("Noresult Exception generer=" + e.getMessage());
            return (Collection<Semestre>) pl;
        } catch (NullPointerException e) {
           Semestre pl = new Semestre();
            pl.setCode(null);
            pl.setLibelleFr(null);
            System.out.println("NullPointerException generer=" + e.getMessage());
            return (Collection<Semestre>) pl;
        }
    }

    //---fonction permettant de retourner la liste des étudiants inscrits---
    @Override
    public Collection<Etudiant> getListEtudiant(int idsemestre,int idannee,int idoptions) {
        String sql="SELECT DISTINCT E.* FROM Etudiant E JOIN inscription I ON I.idetudiant=E.idetudiant WHERE idoptionsemestre='"+idsemestre+"' AND idannee='"+idannee+"' AND idoptions='"+idoptions+"' ORDER BY E.nometud,prenometud";
        try{
        Query query=ema.createNativeQuery(sql,Etudiant.class);
        return query.getResultList();
        } catch (NoResultException e) {
            Etudiant pl = new Etudiant();
            System.out.println("Noresult Exception generer=" + e.getMessage());
            return (Collection<Etudiant>) pl;
        } catch (NullPointerException e) {
            Etudiant pl = new Etudiant();
            System.out.println("NullPointerException generer=" + e.getMessage());
            return (Collection<Etudiant>) pl;
        }
    }
    
    //---fonction permettant de retourner la derniere note de l'etudiant a une matiere---
    @Override
    public Noteevaluation returnLastNoteEtudMat(int idMatiere,int idEtudiant) {
        String sql="SELECT nt.* FROM noteevaluation nt JOIN `session` se ON nt.idSession=se.idSession JOIN annee an ON an.idannee=se.idannee WHERE nt.idEtudiant='"+idEtudiant+"' AND nt.idMatiere='"+idMatiere+"' ORDER BY an.libelle_fr DESC,se.libelle_fr DESC LIMIT 1 ";
        try{
        Query query=ema.createNativeQuery(sql,Noteevaluation.class);
        return (Noteevaluation)query.getSingleResult();
        } catch (NoResultException e) {
            Noteevaluation pl = new Noteevaluation();
            System.out.println("Noresult Exception generer=" + e.getMessage());
            return (Noteevaluation) pl;
        } catch (NullPointerException e) {
            Noteevaluation pl = new Noteevaluation();
            System.out.println("NullPointerException generer=" + e.getMessage());
            return (Noteevaluation) pl;
        }
    }
    
    //---fonction permettant de retourner la derniere note de l'etudiant a une matiere---
    @Override 
    public Ue getInfoUeById(int idUE) {
        try{
        Query query = ema.createNamedQuery("Ue.findByIdue");
        query.setParameter("idue", idUE);
        return (Ue)query.getSingleResult();
        } catch (NoResultException e) {
            Ue pl = new Ue();
            System.out.println("Noresult Exception generer=" + e.getMessage());
            return (Ue) pl;
        } catch (NullPointerException e) {
            Ue pl = new Ue();
            System.out.println("NullPointerException generer=" + e.getMessage());
            return (Ue) pl;
        }
    }
    
    //---fonction permettant de retourner la liste des semestres---
    @Override
    public Etudiant getEtudiantByIds(int idEtudiant){
        try {
            Query query = ema.createNamedQuery("Etudiant.findByIdEtudiant");
            query.setParameter("idEtudiant", idEtudiant);
            Etudiant pl = (Etudiant)query.getSingleResult();
            return pl;
        } catch (NoResultException e){
            Etudiant pl = new Etudiant();
            System.out.println("Noresult Exception generer=" + e.getMessage());
            return (Etudiant) pl;
        } catch (NullPointerException e){
           Etudiant pl = new Etudiant();
            System.out.println("NullPointerException generer=" + e.getMessage());
            return (Etudiant) pl;
        }
    }
    
    /*
     * Fonction permettant de retourner 
     * la liste des enseignants
     */
    @Override
    public Collection<Enseignant> getEnseignantByIdDept(int idDepartement){
        try {
            Query query = ema.createNamedQuery("Enseignant.findByIddepartement");
            query.setParameter("iddepartement", idDepartement);
            Collection<Enseignant> lt = query.getResultList();
            return lt;
        } catch (NoResultException e) {
            Enseignant ens = new Enseignant();
            System.out.println("Noresult Exception generer=" + e.getMessage());
            return (Collection<Enseignant>) ens;
        } catch (NullPointerException e) {
            Enseignant ens = new Enseignant();
            System.out.println("NullPointerException generer=" + e.getMessage());
            return (Collection<Enseignant>) ens;
        }
    }//-----fin de fonction getListEnseignant
    
    /*
 * fonction permettant de retourner 
 * les matieres de l'UE d'un programme
 */
    @Override
    public Collection<Matiere> getListMatierePrgAdopte(int idAnnee,int idOptions,int idSemestre) {
        String sql="SELECT DISTINCT ma.* FROM matiere ma JOIN matiereue me ON ma.idMatiere=me.idMatiere JOIN ue u ON u.idue=me.idue JOIN ueprogramme up ON "
                + "up.idue=u.idue JOIN programme prg ON prg.idProgramme=up.idProgramme JOIN programmeadopte pa ON pa.idProgramme=prg.idProgramme "
                + "WHERE pa.idannee='"+idAnnee+"' AND pa.idoptions='"+idOptions+"' AND pa.idsemestre='"+idSemestre+"'";
        try{
            Query query = ema.createNativeQuery(sql,Matiere.class);
            Collection<Matiere> pl = query.getResultList();
            return pl;
        } catch (NoResultException e) {
            Matiere pl = new Matiere();
            System.out.println("Noresult Exception generer=" + e.getMessage());
            return (Collection<Matiere>) pl;
        } catch (NullPointerException e) {
            Matiere pl = new Matiere();
            System.out.println("NullPointerException generer=" + e.getMessage());
            return (Collection<Matiere>) pl;
        }
    }

    //---fonction permettant de retourner la liste des Matieres programmees---
    @Override
    public Collection<Matiereprogrammee> getListMatiereprogrammee(int idSession) {
        try {
            Query query = ema.createNamedQuery("Matiereprogrammee.findByIdSession");
            query.setParameter("idSession", idSession);
            Collection<Matiereprogrammee> pl = query.getResultList();
            return pl;
        } catch (NoResultException e) {
            Matiereprogrammee pl = new Matiereprogrammee();
            System.out.println("Noresult Exception generer=" + e.getMessage());
            return (Collection<Matiereprogrammee>) pl;
        } catch (NullPointerException e) {
            Matiereprogrammee pl = new Matiereprogrammee();
            System.out.println("NullPointerException generer=" + e.getMessage());
            return (Collection<Matiereprogrammee>) pl;
        }
    }
    
     /*
 * fonction permettant de retourner 
 * les differentes date des matieres 
 * programmees
 */
    @Override 
    public Collection<Date> getDistinctDateMat(int idSession) { 
        String sql="SELECT DISTINCT dateprogrammee FROM matiereprogrammee WHERE idSession='"+idSession+"'";
        try{
            Query query = ema.createNativeQuery(sql);
            Collection<Date> pl = query.getResultList();
            return pl;
        } catch (NoResultException e) {
            Collection<Date> pl =new ArrayList<Date>();
            System.out.println("Noresult Exception generer=" + e.getMessage());
            return (Collection<Date>)pl;
        } catch (NullPointerException e) {
            Collection<Date> pl =new ArrayList<Date>(); 
            System.out.println("NullPointerException generer=" + e.getMessage());
            return (Collection<Date>) pl;
        }
    }
    
    /*
     * fonction de retour de la liste
     * des plages horaires enregistrées
     * pour les matieres programmees pour 
     * une session
     */

    @Override
    public Collection<Plagehoraire> getListPlageMatPrg(int idSession) {
        String sql="SELECT DISTINCT pl.* FROM plagehoraire pl JOIN matiereprogrammee mp ON pl.idplagehoraire=mp.idplagehoraire WHERE mp.idSession='"+idSession+"'";
        try{
            Query query = ema.createNativeQuery(sql,Plagehoraire.class);
            Collection<Plagehoraire> pl = query.getResultList();
            return pl;
        } catch (NoResultException e) {
            Plagehoraire pl = new Plagehoraire();
            System.out.println("Noresult Exception generer=" + e.getMessage());
            return (Collection<Plagehoraire>) pl;
        } catch (NullPointerException e) {
            Plagehoraire pl = new Plagehoraire();
            System.out.println("NullPointerException generer=" + e.getMessage());
            return (Collection<Plagehoraire>) pl;
        }
    }
    
    /*
     * Fonction de retour d'une salle
     * a partir de son id
     */

    @Override 
    public Salle getSalleById(int idSalle) {
        try {
            Query query = ema.createNamedQuery("Salle.findByIdsalle");
            query.setParameter("idsalle", idSalle);
            Salle sa = (Salle)query.getSingleResult();
            return sa;
        } catch (NoResultException e) {
            Salle sa = new Salle();
            System.out.println("Noresult Exception generer=" + e.getMessage());
            return (Salle) sa;
        } catch (NullPointerException e) {
            Salle sa = new Salle();
            System.out.println("NullPointerException generer=" + e.getMessage());
            return (Salle) sa;
        }
    }//----fin de fonction getSalleById
    
    /*
     * fonction permettant de retourner
     * les infos heures
     */

    @Override
    public Heure getHeureById(int idHeure) {
        try {
            Query query = ema.createNamedQuery("Heure.findByIdheure");
            query.setParameter("idheure", idHeure);
            Heure pl = (Heure)query.getSingleResult();
            return pl;
        } catch (NoResultException e) {
            Heure pl = new Heure();
            System.out.println("Noresult Exception generer=" + e.getMessage());
            return (Heure) pl;
        } catch (NullPointerException e) {
            Heure pl = new Heure();
            System.out.println("NullPointerException generer=" + e.getMessage());
            return (Heure) pl;
        }
    }
    /*
     * fonction permettant de retourner
     * les infos des minutes
     */

    @Override
    public Minuite getMinuteById(int idMinute) {
        try {
            Query query = ema.createNamedQuery("Minuite.findByIdminuite");
            query.setParameter("idminuite", idMinute);
            Minuite pl = (Minuite)query.getSingleResult();
            return pl;
        } catch (NoResultException e) {
            Minuite pl = new Minuite();
            System.out.println("Noresult Exception generer=" + e.getMessage());
            return (Minuite) pl;
        } catch (NullPointerException e) {
            Minuite pl = new Minuite();
            System.out.println("NullPointerException generer=" + e.getMessage());
            return (Minuite) pl;
        }
    }
    
     /*
 * fonction permettant de retourner 
 * l'option d'une matiere d'un programme
 */
    @Override 
    public Options getOptionMatierePrgAdopte(int idAnnee,int idSemestre) {
        String sql="SELECT opt.* FROM matiere ma JOIN matiereue me ON ma.idMatiere=me.idMatiere JOIN ue u ON u.idue=me.idue JOIN ueprogramme up ON up.idue=u.idue JOIN programme prg ON prg.idProgramme=up.idProgramme JOIN programmeadopte pa ON pa.idProgramme=prg.idProgramme JOIN `options` opt ON opt.idoptions=pa.idoptions WHERE pa.idannee='"+idAnnee+"' AND pa.idsemestre='"+idSemestre+"' LIMIT 1";
        try{
            Query query = ema.createNativeQuery(sql,Options.class);
            Options pl =(Options)query.getSingleResult();
            return pl;
        } catch (NoResultException e) {
            Options pl = new Options();
            System.out.println("Noresult Exception generer=" + e.getMessage());
            return (Options) pl;
        } catch (NullPointerException e) {
            Options pl = new Options();
            System.out.println("NullPointerException generer=" + e.getMessage());
            return (Options) pl;
        }
    }

    
}//----fin classe servlet-----

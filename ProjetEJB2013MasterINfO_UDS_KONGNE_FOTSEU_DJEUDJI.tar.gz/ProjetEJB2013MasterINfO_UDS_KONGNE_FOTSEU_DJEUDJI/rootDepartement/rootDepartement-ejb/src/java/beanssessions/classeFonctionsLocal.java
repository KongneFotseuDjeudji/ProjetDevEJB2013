/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package beanssessions;

import entites.*;
import java.util.Collection;
import java.util.Date;
import javax.ejb.Remote;

/**
 *
 * @author Ernest
 */
@Remote
public interface classeFonctionsLocal {
  public Collection<Departement> getListDepartement(); 
  public Collection<Enseignant> getListEnseignant(); 
  public Collection<Salle> getListSalle(); 
  public Collection<Plagehoraire> getListPlage();
  public Collection<Heure> getListHeure();
  public Collection<Minuite> getListMinute();
  public Collection<Surveillant> getListSurveillant();
  public Collection<Ressources> getListRessources();
  public Collection<Annee> getListAnnee();
  public Collection<Cursus> getListCursus(int iddepartement);
  public Collection<Options> getListOptions(int idcursus);
  public Collection<Semestre> getListSemestre();
  public Collection<Programme> getListProgramme();
  public Collection<Session> getListSession(int idannee);
  public Collection<Programmeadopte> getListProgrammeadopte();
  public Collection<Options> getOptionsByIdoption(int idOption);
  public Collection<Programme> getProgrammeadopte(int idAnnee,int idOptions,int idSemestre);
  public Collection<Ue> getListUEProgramme(int idProgramme);
  public Collection<Matiereue> getListMatiereUE(int idUE);
  public Matiere getMatiereId(int idMatiere);
  public Annee getAnneeById(int idannee);
  public Departement getDepartementById(int iddepartement);
  public Cursus getCursusById(int idcursus);
  public Options getOptionById(int idoptions);
  public Semestre getSemestreById(int idSemestre);
  public Session getSessionById(int idSession);
  public Collection<Semestre> getSemestreByClasse(String classe);
  public Collection<Etudiant> getListEtudiant(int idclasse,int idannee,int idoptions);
  public Noteevaluation returnLastNoteEtudMat(int idMatiere,int idEtudiant);
  public Ue getInfoUeById(int idUE);
  public Etudiant getEtudiantByIds(int idEtudiant);
  public Collection<Enseignant> getEnseignantByIdDept(int idDepartement);  
  public Collection<Matiere> getListMatierePrgAdopte(int idAnnee,int idOptions,int idSemestre);
  public Collection<Matiereprogrammee> getListMatiereprogrammee(int idSession);
  public Collection<Date> getDistinctDateMat(int idSession);
  public Collection<Plagehoraire> getListPlageMatPrg(int idSession);
  public Salle getSalleById(int idSalle);
  public Heure getHeureById(int idHeure);
  public Minuite getMinuteById(int idMinute);
  public Options getOptionMatierePrgAdopte(int idAnnee,int idSemestre);
}

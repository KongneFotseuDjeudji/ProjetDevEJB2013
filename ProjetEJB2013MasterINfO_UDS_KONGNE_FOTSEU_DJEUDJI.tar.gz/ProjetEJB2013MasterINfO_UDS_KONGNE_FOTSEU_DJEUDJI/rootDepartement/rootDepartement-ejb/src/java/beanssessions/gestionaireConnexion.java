/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package beanssessions;

import entites.Utilisateur;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

/**
 *
 * @author Thierrynems
 */
@Stateless(mappedName="ContactBean")
public class gestionaireConnexion implements gestionaireConnexionLocal {
    @PersistenceContext(unitName = "rootDepartement-ejbPU")
    private EntityManager ema;

    // Add business logic below. (Right-click in editor and choose
    // "Insert Code > Add Business Method")

     // Add business logic below. (Right-click in editor and choose
    // "Insert Code > Add Business Method")
    
   @Override
   public Utilisateur getInfoUsers(String login, String passwd)
   { 
       try{ 
            Query query = ema.createNamedQuery("Utilisateur.findByLoginPasswd");
            query.setParameter("login", login);
            query.setParameter("passwd", passwd);
            
            return (Utilisateur)query.getSingleResult();
    }catch(NoResultException e){
        Utilisateur user = new Utilisateur();
        user.setLogin(null);
        user.setPasswd(null);
        return user;
    }
    
 }

    public void persist(Object object) {
        ema.persist(object);
    }
   
}

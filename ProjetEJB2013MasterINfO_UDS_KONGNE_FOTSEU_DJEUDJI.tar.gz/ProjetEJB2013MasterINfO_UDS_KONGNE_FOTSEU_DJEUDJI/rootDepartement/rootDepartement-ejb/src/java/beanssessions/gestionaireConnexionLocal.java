/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package beanssessions;

import entites.Utilisateur;
import javax.ejb.Remote;

/**
 *
 * @author Thierrynems
 */
@Remote
public interface gestionaireConnexionLocal {

    public Utilisateur getInfoUsers(String login, String passwd);
    
}

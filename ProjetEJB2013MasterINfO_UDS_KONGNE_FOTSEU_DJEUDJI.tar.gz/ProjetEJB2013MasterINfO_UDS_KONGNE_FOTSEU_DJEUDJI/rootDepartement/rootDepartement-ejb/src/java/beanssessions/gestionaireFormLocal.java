/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package beanssessions;

import javax.ejb.Remote;

/**
 *
 * @author Ernest
 */
@Remote
public interface gestionaireFormLocal {
  public void save(Object e);   
}

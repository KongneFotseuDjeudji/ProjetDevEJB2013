function getXhr() {
    if (window.XMLHttpRequest) {
        if (navigator.userAgent.indexOf('MSIE') != -1) {
            isIE = true;
        }
        return new XMLHttpRequest();
    } else if (window.ActiveXObject) {
        isIE = true;
        return new ActiveXObject("Microsoft.XMLHTTP");
    }
}
//fonction de chargement de la session connaissant l'annee
function chargeChamp(champ){
    var xhr = getXhr();
   // alert(champ);
    if(champ=="session"){
    xhr.onreadystatechange = function()
         {
            // On ne fait quelque chose que si on a tout reçu et que le serveur est ok
            if (xhr.readyState == 4 && xhr.status == 200)
            {
                texte = xhr.responseText;
                // On se sert de innerHTML pour rajouter les options a la liste
                document.getElementById("contendSession").innerHTML = texte;
            }
         }
        var idannee=document.getElementById('idannee').value;
        xhr.open("GET", "ajax/ajaxSaisieCC.jsp?annee=" + idannee+"&function=chargeSession", true);
        xhr.send(null);
    }else if(champ=="options"){
        xhr.onreadystatechange = function()
         {
            // On ne fait quelque chose que si on a tout reçu et que le serveur est ok
            if (xhr.readyState == 4 && xhr.status == 200)
            {
                texte = xhr.responseText;
                // On se sert de innerHTML pour rajouter les options a la liste
                document.getElementById("contendOption").innerHTML = texte;
            }
         }
        var idcursus=document.getElementById('idcursus').value;
        xhr.open("GET", "ajax/ajaxSaisieCC.jsp?cursus=" + idcursus+"&function=chargeOption", true);
        xhr.send(null);
    }else if(champ=="matiere"){
        xhr.onreadystatechange = function()
         {
            // On ne fait quelque chose que si on a tout reçu et que le serveur est ok
            if (xhr.readyState == 4 && xhr.status == 200)
            {
                texte = xhr.responseText;
                // On se sert de innerHTML pour rajouter les options a la liste
                document.getElementById("contendMatiere").innerHTML = texte;
            }
         }
        var idsession=document.getElementById('idsession').value;
        var idsemestre=document.getElementById('idsemestre').value;
        xhr.open("GET", "ajax/ajaxSaisieCC.jsp?session=" + idsession+"&function=chargeMatiere&semestre="+idsemestre, true);
        xhr.send(null);
    }else if(champ=="CreateEval"){
        xhr.onreadystatechange = function()
         {
            // On ne fait quelque chose que si on a tout reçu et que le serveur est ok
            if (xhr.readyState == 4 && xhr.status == 200)
            {
                texte = xhr.responseText;
                // On se sert de innerHTML pour rajouter les options a la liste
                document.getElementById("contendEval").innerHTML = texte;
            }
         }
        var idsession=document.getElementById('idsession').value;
        var idsemestre=document.getElementById('idsemestre').value;
        var idmatiere=document.getElementById('idmatiere').value;
        var poidseval=document.getElementById('idpoidseval').value;
        var idannee=document.getElementById('idannee').value;
        var idoption=document.getElementById('idoption').value;
        if(idsession!=-1 && idsemestre!=-1 && idmatiere!=-1 && poidseval!=-1){
            xhr.open("GET", "ajax/ajaxSaisieCC.jsp?session=" + idsession+"&function=CreatEval&semestre="+idsemestre+"&matiere="+idmatiere+"&poideval="+poidseval+"&annee="+idannee+"&options="+idoption, true);
            xhr.send(null);   
        }else{
            alert('Veuillez renseigner tous les champs svp !!!');
        }
        
    }else if(champ=="ChargeEval"){
    //    alert (champ);
        xhr.onreadystatechange = function()
         {
            // On ne fait quelque chose que si on a tout reçu et que le serveur est ok
            if (xhr.readyState == 4 && xhr.status == 200)
            {
                texte = xhr.responseText;
                // On se sert de innerHTML pour rajouter les options a la liste
                document.getElementById("contendEval").innerHTML = texte;
            }
         }
        
        var idsession=document.getElementById('idsession').value;
        var idsemestre=document.getElementById('idsemestre').value;
        var idmatiere=document.getElementById('idmatiere').value;
        var poidseval=document.getElementById('idpoidseval').value;
        var idannee=document.getElementById('idannee').value;
        var idoption=document.getElementById('idoption').value;
        var idtypeevaluation=1;
        if(idsession!=-1 && idsemestre!=-1 && idmatiere!=-1 && poidseval!=-1){
            xhr.open("GET", "ajax/ajaxSaisieCC.jsp?session=" + idsession+"&function=ChargeEval&semestre="+idsemestre+"&matiere="+idmatiere+"&poideval="+poidseval+"&typeeval="+idtypeevaluation+"&annee="+idannee+"&options="+idoption, true);
            xhr.send(null);   
        }else{
            alert('Veuillez renseigner tous les champs svp !!!');
        }
        
    }else if(champ=="ChargeEvalAno"){ 
          // On ne fait quelque chose que si on a tout reçu et que le serveur est ok
            if (xhr.readyState == 4 && xhr.status == 200){
                texte = xhr.responseText;
                // On se sert de innerHTML pour rajouter les options a la liste
                document.getElementById("contendEval").innerHTML = texte;
            }       
        var idsession=document.getElementById('idsession').value;
        var idsemestre=document.getElementById('idsemestre').value;
        var idmatiere=document.getElementById('idmatiere').value;
        var poidseval=document.getElementById('idpoidseval').value;
        var idannee=document.getElementById('idannee').value;
        var idoption=document.getElementById('idoption').value;
        var idtypeevaluation=2;
        if(idsession!=-1 && idsemestre!=-1 && idmatiere!=-1 && poidseval!=-1){
            xhr.open("GET", "ajax/ajaxSaisieCC.jsp?session=" + idsession+"&function=ChargeEval&semestre="+idsemestre+"&matiere="+idmatiere+"&poideval="+poidseval+"&typeeval="+idtypeevaluation+"&annee="+idannee+"&options="+idoption, true);
            xhr.send(null);   
        }else{
            alert('Veuillez renseigner tous les champs svp !!!');
        }
    } 
}

//charge champ anonymats 
function chargeChampAno(champ){
    var xhr = getXhr();
   // alert(champ);
    if(champ=="session"){
    xhr.onreadystatechange = function()
         {
            // On ne fait quelque chose que si on a tout reçu et que le serveur est ok
            if (xhr.readyState == 4 && xhr.status == 200)
            {
                texte = xhr.responseText;
                // On se sert de innerHTML pour rajouter les options a la liste
                document.getElementById("contendSession").innerHTML = texte;
            }
         }
        var idannee=document.getElementById('idannee').value;
        xhr.open("GET", "ajax/ajaxSaisieAnonymats.jsp?annee=" + idannee+"&function=chargeSession", true);
        xhr.send(null);
    }else if(champ=="options"){
        xhr.onreadystatechange = function()
         {
            // On ne fait quelque chose que si on a tout reçu et que le serveur est ok
            if (xhr.readyState == 4 && xhr.status == 200)
            {
                texte = xhr.responseText;
                // On se sert de innerHTML pour rajouter les options a la liste
                document.getElementById("contendOption").innerHTML = texte;
            }
         }
        var idcursus=document.getElementById('idcursus').value;
        xhr.open("GET", "ajax/ajaxSaisieAnonymats.jsp?cursus=" + idcursus+"&function=chargeOption", true);
        xhr.send(null);
    }else if(champ=="matiere"){
        xhr.onreadystatechange = function()
         {
            // On ne fait quelque chose que si on a tout reçu et que le serveur est ok
            if (xhr.readyState == 4 && xhr.status == 200)
            {
                texte = xhr.responseText;
                // On se sert de innerHTML pour rajouter les options a la liste
                document.getElementById("contendMatiere").innerHTML = texte;
            }
         }
        var idsession=document.getElementById('idsession').value;
        var idsemestre=document.getElementById('idsemestre').value;
        xhr.open("GET", "ajax/ajaxSaisieAnonymats.jsp?session=" + idsession+"&function=chargeMatiere&semestre="+idsemestre, true);
        xhr.send(null);
    }else if(champ=="CreateEval"){
        xhr.onreadystatechange = function()
         {
            // On ne fait quelque chose que si on a tout reçu et que le serveur est ok
            if (xhr.readyState == 4 && xhr.status == 200)
            {
                texte = xhr.responseText;
                // On se sert de innerHTML pour rajouter les options a la liste
                document.getElementById("contendEval").innerHTML = texte;
            }
         }
        var idsession=document.getElementById('idsession').value;
        var idsemestre=document.getElementById('idsemestre').value;
        var idmatiere=document.getElementById('idmatiere').value;
        var poidseval=document.getElementById('idpoidseval').value;
        var idannee=document.getElementById('idannee').value;
        var idoption=document.getElementById('idoption').value;
        if(idsession!=-1 && idsemestre!=-1 && idmatiere!=-1 && poidseval!=-1){
            xhr.open("GET", "ajax/ajaxSaisieAnonymats.jsp?session=" + idsession+"&function=CreatEval&semestre="+idsemestre+"&matiere="+idmatiere+"&poideval="+poidseval+"&annee="+idannee+"&options="+idoption, true);
            xhr.send(null);   
        }else{
            alert('Veuillez renseigner tous les champs svp !!!');
        }
        
    }else if(champ=="ChargeEval"){
    //    alert (champ);
        xhr.onreadystatechange = function()
         {
            // On ne fait quelque chose que si on a tout reçu et que le serveur est ok
            if (xhr.readyState == 4 && xhr.status == 200)
            {
                texte = xhr.responseText;
                // On se sert de innerHTML pour rajouter les options a la liste
                document.getElementById("contendEval").innerHTML = texte;
            }
         }
        
        var idsession=document.getElementById('idsession').value;
        var idsemestre=document.getElementById('idsemestre').value;
        var idmatiere=document.getElementById('idmatiere').value;
        var poidseval=document.getElementById('idpoidseval').value;
        var idannee=document.getElementById('idannee').value;
        var idoption=document.getElementById('idoption').value;
        var idtypeevaluation=2;
        if(idsession!=-1 && idsemestre!=-1 && idmatiere!=-1 && poidseval!=-1){
            xhr.open("GET", "ajax/ajaxSaisieAnonymats.jsp?session=" + idsession+"&function=ChargeEval&semestre="+idsemestre+"&matiere="+idmatiere+"&poideval="+poidseval+"&typeeval="+idtypeevaluation+"&annee="+idannee+"&options="+idoption, true);
            xhr.send(null);   
        }else{
            alert('Veuillez renseigner tous les champs svp !!!');
        }
        
    }
}

//charge champ anonymats 
function chargeChampAno(champ){
    var xhr = getXhr();
   // alert(champ);
    if(champ=="session"){
    xhr.onreadystatechange = function()
         {
            // On ne fait quelque chose que si on a tout reçu et que le serveur est ok
            if (xhr.readyState == 4 && xhr.status == 200)
            {
                texte = xhr.responseText;
                // On se sert de innerHTML pour rajouter les options a la liste
                document.getElementById("contendSession").innerHTML = texte;
            }
         }
        var idannee=document.getElementById('idannee').value;
        xhr.open("GET", "ajax/ajaxSaisieAnonymats.jsp?annee=" + idannee+"&function=chargeSession", true);
        xhr.send(null);
    }else if(champ=="options"){
        xhr.onreadystatechange = function()
         {
            // On ne fait quelque chose que si on a tout reçu et que le serveur est ok
            if (xhr.readyState == 4 && xhr.status == 200)
            {
                texte = xhr.responseText;
                // On se sert de innerHTML pour rajouter les options a la liste
                document.getElementById("contendOption").innerHTML = texte;
            }
         }
        var idcursus=document.getElementById('idcursus').value;
        xhr.open("GET", "ajax/ajaxSaisieAnonymats.jsp?cursus=" + idcursus+"&function=chargeOption", true);
        xhr.send(null);
    }else if(champ=="matiere"){
        xhr.onreadystatechange = function()
         {
            // On ne fait quelque chose que si on a tout reçu et que le serveur est ok
            if (xhr.readyState == 4 && xhr.status == 200)
            {
                texte = xhr.responseText;
                // On se sert de innerHTML pour rajouter les options a la liste
                document.getElementById("contendMatiere").innerHTML = texte;
            }
         }
        var idsession=document.getElementById('idsession').value;
        var idsemestre=document.getElementById('idsemestre').value;
        xhr.open("GET", "ajax/ajaxSaisieAnonymats.jsp?session=" + idsession+"&function=chargeMatiere&semestre="+idsemestre, true);
        xhr.send(null);
    }else if(champ=="CreateEval"){
        xhr.onreadystatechange = function()
         {
            // On ne fait quelque chose que si on a tout reçu et que le serveur est ok
            if (xhr.readyState == 4 && xhr.status == 200)
            {
                texte = xhr.responseText;
                // On se sert de innerHTML pour rajouter les options a la liste
                document.getElementById("contendEval").innerHTML = texte;
            }
         }
        var idsession=document.getElementById('idsession').value;
        var idsemestre=document.getElementById('idsemestre').value;
        var idmatiere=document.getElementById('idmatiere').value;
        var poidseval=document.getElementById('idpoidseval').value;
        var idannee=document.getElementById('idannee').value;
        var idoption=document.getElementById('idoption').value;
        if(idsession!=-1 && idsemestre!=-1 && idmatiere!=-1 && poidseval!=-1){
            xhr.open("GET", "ajax/ajaxSaisieAnonymats.jsp?session=" + idsession+"&function=CreatEval&semestre="+idsemestre+"&matiere="+idmatiere+"&poideval="+poidseval+"&annee="+idannee+"&options="+idoption, true);
            xhr.send(null);   
        }else{
            alert('Veuillez renseigner tous les champs svp !!!');
        }
        
    }else if(champ=="ChargeEval"){
    //    alert (champ);
        xhr.onreadystatechange = function()
         {
            // On ne fait quelque chose que si on a tout reçu et que le serveur est ok
            if (xhr.readyState == 4 && xhr.status == 200)
            {
                texte = xhr.responseText;
                // On se sert de innerHTML pour rajouter les options a la liste
                document.getElementById("contendEval").innerHTML = texte;
            }
         }
        
        var idsession=document.getElementById('idsession').value;
        var idsemestre=document.getElementById('idsemestre').value;
        var idmatiere=document.getElementById('idmatiere').value;
        var poidseval=document.getElementById('idpoidseval').value;
        var idannee=document.getElementById('idannee').value;
        var idoption=document.getElementById('idoption').value;
        var idtypeevaluation=2;
        if(idsession!=-1 && idsemestre!=-1 && idmatiere!=-1 && poidseval!=-1){
            xhr.open("GET", "ajax/ajaxSaisieAnonymats.jsp?session=" + idsession+"&function=ChargeEval&semestre="+idsemestre+"&matiere="+idmatiere+"&poideval="+poidseval+"&typeeval="+idtypeevaluation+"&annee="+idannee+"&options="+idoption, true);
            xhr.send(null);   
        }else{
            alert('Veuillez renseigner tous les champs svp !!!');
        }
        
    }
}

//charge champ anonymats 
function chargeChampExam(champ){
    var xhr = getXhr();
   // alert(champ);
    if(champ=="session"){
    xhr.onreadystatechange = function()
         {
            // On ne fait quelque chose que si on a tout reçu et que le serveur est ok
            if (xhr.readyState == 4 && xhr.status == 200)
            {
                texte = xhr.responseText;
                // On se sert de innerHTML pour rajouter les options a la liste
                document.getElementById("contendSession").innerHTML = texte;
            }
         }
        var idannee=document.getElementById('idannee').value;
        xhr.open("GET", "ajax/ajaxSaisieExam.jsp?annee=" + idannee+"&function=chargeSession", true);
        xhr.send(null);
    }else if(champ=="options"){
        xhr.onreadystatechange = function()
         {
            // On ne fait quelque chose que si on a tout reçu et que le serveur est ok
            if (xhr.readyState == 4 && xhr.status == 200){
                texte = xhr.responseText;
                // On se sert de innerHTML pour rajouter les options a la liste
                document.getElementById("contendOption").innerHTML = texte;
            }
         }
        var idcursus=document.getElementById('idcursus').value;
        xhr.open("GET", "ajax/ajaxSaisieExam.jsp?cursus=" + idcursus+"&function=chargeOption", true);
        xhr.send(null);
    }else if(champ=="matiere"){
        xhr.onreadystatechange = function()
         {
            // On ne fait quelque chose que si on a tout reçu et que le serveur est ok
            if (xhr.readyState == 4 && xhr.status == 200)
            {
                texte = xhr.responseText;
                // On se sert de innerHTML pour rajouter les options a la liste
                document.getElementById("contendMatiere").innerHTML = texte;
            }
         }
        var idsession=document.getElementById('idsession').value;
        var idsemestre=document.getElementById('idsemestre').value;
        xhr.open("GET", "ajax/ajaxSaisieExam.jsp?session=" + idsession+"&function=chargeMatiere&semestre="+idsemestre, true);
        xhr.send(null);
    }else if(champ=="ChargeEval"){
    //    alert (champ);
        xhr.onreadystatechange = function()
         {
            // On ne fait quelque chose que si on a tout reçu et que le serveur est ok
            if (xhr.readyState == 4 && xhr.status == 200)
            {
                texte = xhr.responseText;
                // On se sert de innerHTML pour rajouter les options a la liste
                document.getElementById("contendEval").innerHTML = texte;
            }
         }
        
        var idsession=document.getElementById('idsession').value;
        var idsemestre=document.getElementById('idsemestre').value;
        var idmatiere=document.getElementById('idmatiere').value;
        var idannee=document.getElementById('idannee').value;
        var idoption=document.getElementById('idoption').value;
        var idtypeevaluation=2;
        if(idsession!=-1 && idsemestre!=-1 && idmatiere!=-1){
            xhr.open("GET", "ajax/ajaxSaisieExam.jsp?session=" + idsession+"&function=ChargeEval&semestre="+idsemestre+"&matiere="+idmatiere+"&typeeval="+idtypeevaluation+"&annee="+idannee+"&options="+idoption, true);
            xhr.send(null);   
        }else{
            alert('Veuillez renseigner tous les champs svp !!!');
        }
        
    }
}
//charge info Emploi de temps 
function ChargeEmploiTemps(champ){
    var xhr = getXhr();
   if(champ=="charge"){
    xhr.onreadystatechange = function()
         {
            // On ne fait quelque chose que si on a tout reçu et que le serveur est ok
            if (xhr.readyState == 4 && xhr.status == 200)
            {
                texte = xhr.responseText;
                // On se sert de innerHTML pour rajouter les options a la liste
                document.getElementById("contendData").innerHTML = texte;
            }
         }
        var idsession=document.getElementById('idsession').value;
        var idsemestre=document.getElementById('idsemestre').value;
        var idannee=document.getElementById('idannee').value;
        var idoption=document.getElementById('idoption').value;
         if(idsession!=-1 && idsemestre!=-1){
            xhr.open("GET", "ajax/ajaxEmploiTemps.jsp?session=" + idsession+"&function=ChargeMat&semestre="+idsemestre+"&annee="+idannee+"&options="+idoption, true);
            xhr.send(null); 
             document.getElementById('contendData').innerHTML = '<img src="images/ajax-loader(9).gif" border="0"><br>Veuillez patienter ...<br>Cette op&eacute;ration peut prendre quelques minutes';
        }else{
            alert('Veuillez renseigner tous les champs svp !!!');
        }
     }else{
         xhr.onreadystatechange = function()
         {
            // On ne fait quelque chose que si on a tout reçu et que le serveur est ok
            if (xhr.readyState == 4 && xhr.status == 200)
            {
                texte = xhr.responseText;
                // On se sert de innerHTML pour rajouter les options a la liste
                document.getElementById("content_"+champ).innerHTML = texte;
            }
         }
       //  alert(champ);
        var idsession=document.getElementById('idsession').value;
        var idsemestre=document.getElementById('idsemestre').value;
        var idannee=document.getElementById('idannee').value;
        var idoption=document.getElementById('idoption').value;
        var idenseignant=document.getElementById('ens_'+champ).value;
        var idplage=document.getElementById('hor_'+champ).value;
        var idsalle=document.getElementById('salle_'+champ).value;
        var date = document.getElementById('date_'+champ).value;
       // alert(date);
        xhr.open("GET", "ajax/ajaxEmploiTemps.jsp?session=" + idsession+"&function=Save&semestre="+idsemestre+"&annee="+idannee+"&options="+idoption+"&idenseignant="+idenseignant+"&idplage="+idplage+"&idsalle="+idsalle+"&date="+date+"&idmatiere="+champ, true);
        xhr.send(null);
     }
  }
  function ImprimeEmploiTemps(){
      var xhr = getXhr();
      xhr.onreadystatechange = function()
         {
            // On ne fait quelque chose que si on a tout reçu et que le serveur est ok
            if (xhr.readyState == 4 && xhr.status == 200)
            {
                texte = xhr.responseText;
                // On se sert de innerHTML pour rajouter les options a la liste
                document.getElementById("contentData").innerHTML = texte;
            }
         }
        var idsession=document.getElementById('idsession').value;
        var idsemestre=document.getElementById('idsemestre').value;
        var idannee=document.getElementById('idannee').value;
        var idoption=document.getElementById('idoption').value;
         if(idsession!=-1 && idsemestre!=-1){
            xhr.open("GET", "ajax/ajaxImprimeEmploiTemps.jsp?session=" + idsession+"&function=ChargeMat&semestre="+idsemestre+"&annee="+idannee+"&options="+idoption, true);
            xhr.send(null); 
             document.getElementById('contentData').innerHTML = '<img src="images/ajax-loader(9).gif" border="0"><br>Veuillez patienter ...<br>Cette op&eacute;ration peut prendre quelques minutes';
   }
 }  

//function de sauvegarde de la note
//saveEval(event,"+idetudiant+","+idsession+","+idsemestre+","+idmatiere+","+idevaluation+","+idannee+",1)
function saveEval(evt,idetudiant,idsession,idsemestre,idmatiere,idevaluation,idannee,idoptions,type){
    //type=1 enregistrement individuel, 0 enregistrement global
    var xhr = getXhr();
    if(type==1){//cas de l'enregistrement individuel 
        xhr.onreadystatechange = function()
         {
            // On ne fait quelque chose que si on a tout reçu et que le serveur est ok
            if (xhr.readyState == 4 && xhr.status == 200)
            {
                texte = xhr.responseText;
                // On se sert de innerHTML pour rajouter les options a la liste
                var zoneId='tr'+idetudiant;
                renvoieFocus(idetudiant);
                document.getElementById(zoneId).innerHTML = texte;
            }
         }
         
        var keyCode = evt.which ? evt.which : evt.keyCode;
        var interdit = 'AZERTYUIOPQSDFGHJKLMWXCVBN azoertyuipqsdfghjklmwxcvbn-_àâäãçéèêëìîïòôöõùûüñù °§ù&*?!:;,¤#~"^¨$£?²¤§*()[]{}<>|\\/`\µ°ÖÜÄÏ+'; 
            if(interdit.indexOf(String.fromCharCode(keyCode)) >= 0){
                        return false;		
                 }
                 else if(evt.keyCode==39 || evt.keyCode==37){
                   return true;
                 }
                 
                  if(evt.keyCode==13){  
                   var note=document.getElementById(idetudiant).value;  
                   if(note<=20 && note >=0){
                   
                        //xhr.open("GET", "ajax/ajaxSaisieCC.jsp?session=" + idsession+"&function=ChargeEval&semestre="+idsemestre+"&matiere="+idmatiere+"&poideval="+poidseval+"&typeeval="+idtypeevaluation+"&annee="+idannee+"&options="+idoption, true);
                        xhr.open("GET", "ajax/ajaxSaisieCC.jsp?note="+note+"&function=SaveEval&session="+idsession+"&semestre="+idsemestre+"&matiere="+idmatiere+"&evaluation="+idevaluation+"&annee="+idannee+"&etudiant="+idetudiant+"&options="+idoptions, true);
                        xhr.send(null); 
                    }else{
                        document.getElementById(idetudiant).value="";
                        var zoneId='tr'+idetudiant;
                        document.getElementById(zoneId).innerHTML ="<img src='images/s_error.png' alt='ko' title='Note invalide' />";
                    }
                    
                  }
                } else if(type==2){//saisie anonymat
                    xhr.onreadystatechange = function()
         {
            // On ne fait quelque chose que si on a tout reçu et que le serveur est ok
            if (xhr.readyState == 4 && xhr.status == 200)
            {
                texte = xhr.responseText;
                // On se sert de innerHTML pour rajouter les options a la liste
                var zoneId='tr'+idetudiant;
                renvoieFocus(idetudiant);
                document.getElementById(zoneId).innerHTML = texte;
            }
         }
         
                  if(evt.keyCode==13){  
                   var anonymat=document.getElementById(idetudiant).value;  
                   if(anonymat!=""){
                   
                        //xhr.open("GET", "ajax/ajaxSaisieCC.jsp?session=" + idsession+"&function=ChargeEval&semestre="+idsemestre+"&matiere="+idmatiere+"&poideval="+poidseval+"&typeeval="+idtypeevaluation+"&annee="+idannee+"&options="+idoption, true);
                        xhr.open("GET", "ajax/ajaxSaisieAnonymats.jsp?anonymat="+anonymat+"&function=SaveAno&session="+idsession+"&semestre="+idsemestre+"&matiere="+idmatiere+"&evaluation="+idevaluation+"&annee="+idannee+"&etudiant="+idetudiant+"&options="+idoptions, true);
                        xhr.send(null); 
                    }else{
                        document.getElementById(idetudiant).value="";
                        var zoneId='tr'+idetudiant;
                        document.getElementById(zoneId).innerHTML ="<img src='images/s_error.png' alt='ko' title='Anonymat invalide' />";
                    }
                    
                  }
                }else if(type==3){//saisie examen
                   xhr.onreadystatechange = function()
                {
            // On ne fait quelque chose que si on a tout reçu et que le serveur est ok
            if (xhr.readyState == 4 && xhr.status == 200)
            {
                texte = xhr.responseText;
                // On se sert de innerHTML pour rajouter les options a la liste
                var zoneId='tr'+idetudiant;
                renvoieFocus(idetudiant);
                document.getElementById(zoneId).innerHTML = texte;
            }
         }
         
        var keyCode = evt.which ? evt.which : evt.keyCode;
        var interdit = 'AZERTYUIOPQSDFGHJKLMWXCVBN azoertyuipqsdfghjklmwxcvbn-_àâäãçéèêëìîïòôöõùûüñù °§ù&*?!:;,¤#~"^¨$£?²¤§*()[]{}<>|\\/`\µ°ÖÜÄÏ+'; 
            if(interdit.indexOf(String.fromCharCode(keyCode)) >= 0){
                        return false;		
                 }
                 else if(evt.keyCode==39 || evt.keyCode==37){
                   return true;
                 }
                 
                  if(evt.keyCode==13){  
                   var note=document.getElementById(idetudiant).value;  
                   if(note<=20 && note >=0){
                   
                        //xhr.open("GET", "ajax/ajaxSaisieCC.jsp?session=" + idsession+"&function=ChargeEval&semestre="+idsemestre+"&matiere="+idmatiere+"&poideval="+poidseval+"&typeeval="+idtypeevaluation+"&annee="+idannee+"&options="+idoption, true);
                        xhr.open("GET", "ajax/ajaxSaisieExam.jsp?note="+note+"&function=SaveEval&session="+idsession+"&semestre="+idsemestre+"&matiere="+idmatiere+"&evaluation="+idevaluation+"&annee="+idannee+"&etudiant="+idetudiant+"&options="+idoptions, true);
                        xhr.send(null); 
                    }else{
                        document.getElementById(idetudiant).value="";
                        var zoneId='tr'+idetudiant;
                        document.getElementById(zoneId).innerHTML ="<img src='images/s_error.png' alt='ko' title='Note invalide' />";
                    }
                    
                  } 
                } 
      /*  var idsemestre=document.getElementById('idsemestre').value;
        var idmatiere=document.getElementById('idmatiere').value;
        var poidseval=document.getElementById('idpoidseval').value;
        var idannee=document.getElementById('idannee').value;
        var idoption=document.getElementById('idoption').value;
        var idtypeevaluation=1;*/ 
        
   }
 
function renvoieFocus(idElt) {

	var tabInput = document.getElementsByTagName("input");
	var indexElt=0;
        var suivant=0;
	for(var ii=0;ii<tabInput.length;ii++) {
		if(tabInput[ii].name==idElt){
                    indexElt=ii;
                    break;
                }
	}
        suivant=indexElt +1;
     //   alert(suivant);
        if(suivant==tabInput.length){
            //dernier element on ramene le cursus en haut
            tabInput[0].focus();
            tabInput[0].select();
        }else{
            tabInput[suivant].focus();
            tabInput[suivant].select();
        }
	
}

function change_cursor(status, eltId) {
    if (status == '1')
        alert(gid(eltId).style.border); // = 'pointer';
    else
        gid(eltId).style.cursor = 'default';
}
function getElementsByClass(searchClass, node, tag) {
    var classElements = new Array();
    if (node == null)
        node = document;
    if (tag == null)
        tag = '*';
    var els = node.getElementsByTagName(tag);
    var elsLen = els.length;
    var pattern = new RegExp("(^|\\\\s)" + searchClass + "(\\\\s|$)");
    for (i = 0, j = 0; i < elsLen; i++) {
        if (pattern.test(els[i].className)) {
            classElements[j] = els[i];
            j++;
        }
    }
    return classElements;
}



function getSelectedOption(obj) {
    if (obj.options && obj.selectedIndex) {
        return obj.options[obj.selectedIndex].value;
    } else {
        return false;
    }
}

function gid(id) {
    return document.getElementById(id);
}

function isEmail(text) {
    var pattern = "^[\\w-_\.]*[\\w-_\.]\@[\\w]\.+[\\w]+[\\w]$";
    var regex = new RegExp(pattern);
    return regex.test(text);
}

function isNumeric(text) {
    var pattern = "[0-9]";
    var regex = new RegExp(pattern);
    return regex.test(text);
}


function trim(str) {
    return str.replace(/^\s+|\s+$/g, '');
}

/*
 *function de connexion 
 */
function connexion() {

    var tabInput = document.getElementsByTagName("input");
    var valide=true;
    for (var i = 0; i < tabInput.length; i++) {
        if (tabInput[i].className == "requis") {
            if (trim(tabInput[i].value) == "") {
                tabInput[i].style.border = "solid 1px red";
                tabInput[i].style.backgroundColor = "#ffffff";
                gid("load").innerHTML ="<span style='color:#F00'>Veuillez renseigner tous les champs</span>";
               // alert(i);
                valide=false;
            }else {
                tabInput[i].style.border = "solid 1px #AAAAAA";
                tabInput[i].style.background = "url(images/input_bg.gif) repeat scroll 0 0 transparent";
                //document.form1.Connexion.submit=submitted;
            }
        }
    }
    return valide;
    /*
     * teste de la valeur valide. si valide=1 alor on soumet au serveur sinon on rouge
     */


    /*
     //soummission sur le serveur 
     
     /*   if(window.navigator.appName.substr(0,9) != "Microsoft") {
     gid("load").innerHTML ="Connexion en cours ...<img src='images/wait/ajax-loader1.gif' />";  
     }
     else {
     gid("load").innerHTML = "Wait ..."; 
     
     jQuery.ajax({
     type: "POST",
     url:"rootPedagogie-war/servletConnexion",
     data: "username=" + document.getElementById('username').value +
     "&password=" + document.getElementById('password').value
     ,
     success: function(message) {
     //$('#contentAdd2').replaceWith(message);
     document.getElementById('load').innerHTML = message;
     }
     });    
     }*/

}
function controleForm() {
    var numNextForm = document.getElementById('nextform').value
    var tabInput = document.getElementsByTagName("input");
    var tabSelect = document.getElementsByTagName("select");
    var valide = 1;

    for (var i = 0; i < tabInput.length; i++) {
        if (tabInput[i].className == "requis") {
            if (trim(tabInput[i].value) == "") {
                //gid("error_" + tabInput[i].id).style.visibility  = "visible";
                //gid("error_" + tabInput[i].id).innerHTML = "<img src='" + BASE_URL + "/images/warning.jpg' title='Champ obligatoire' border='0'>";
                tabInput[i].style.border = "solid 1px red";
                tabInput[i].style.background = "url(" + BASE_URL + "/images/bg-field-error.gif) no-repeat 99% center";

//            tabInput[i].style.background = "#FFCCFF";
                //var chaine = ""
                //document.write('<style></style>')
                //alert(tabInput[i].className);
                //tabInput[i].addClass('field_error');
                valide = 0;
            }
            else {
//            gid("error_" + tabInput[i].id).style.visibility  = "hidden";
//            gid("error_" + tabInput[i].id).innerHTML = "";
                tabInput[i].style.border = "solid 1px #AAAAAA";
                //tabInput[i].style.background = "#FFFFFF";
                tabInput[i].style.background = "url('" + BASE_URL + "/images/img/input_bg.gif') repeat scroll 0 0 transparent";
                //tabInput[i].style.border = "1px solid silver;";
            }
        }
    }

    for (i = 0; i < tabSelect.length; i++) {
        if (tabSelect[i].className == "requis") {
            if (tabSelect[i].id == 'nationaliteetud') {
                if (getValueInTabSelect("nationaliteetud") != "22") {
                    gid("RegionOrigine").disabled = true;
                    gid("RegionOrigine").style.background = "#CCCCCC";
                    gid("DeptOrigine").disabled = true;
                    gid("DeptOrigine").style.background = "#CCCCCC";
                    gid("ArrondisOrigine").disabled = true;
                    gid("ArrondisOrigine").style.background = "#CCCCCC";
                }
            }
            if (tabSelect[i].value == "") {
                if (!tabSelect[i].disabled) {
                    if (tabSelect[i].id != "jourNaiss" && tabSelect[i].id != "moisNaiss") {
                        gid("error_" + tabSelect[i].id).style.visibility = "visible";
                        //gid("error_" + tabSelect[i].id).innerHTML = "<img src='" + BASE_URL + "/images/bg-field-error.gif' title='Champ obligatoire' border='0'>";
                    }
                    //tabSelect[i].style.background="#FFCCFF";
                    //tabSelect[i].style.background = "url(" + BASE_URL + "/images/bg-field-error.gif) no-repeat 99% center";
                    tabSelect[i].style.border = "solid 1px red";
                    valide = 0;
                }
                else {
                    if (tabSelect[i].id != "jourNaiss" && tabSelect[i].id != "moisNaiss") {
                        gid("error_" + tabSelect[i].id).style.visibility = "hidden";
                        gid("error_" + tabSelect[i].id).innerHTML = "";
                    }
                    tabSelect[i].style.background = "#CCCCCC";

                }

            }
            else {
                tabSelect[i].style.border = "solid 1px #AAAAAA";
                if (tabSelect[i].id != "jourNaiss" && tabSelect[i].id != "moisNaiss") {
                    gid("error_" + tabSelect[i].id).style.visibility = "hidden";
                    gid("error_" + tabSelect[i].id).innerHTML = "";
                }
                tabSelect[i].style.background = "#FFFFFF";
                tabSelect[i].style.background = "url('" + BASE_URL + "/images/img/input_bg.gif') repeat scroll 0 0 transparent";
            }
        }
    }

    if (valide == 1) {
        if (window.navigator.appName.substr(0, 9) != "Microsoft") {
            gid("blocchargement").innerHTML = "Veuillez patienter ...<img src='" + BASE_URL + "/images/wait/ajax-loader1.gif'>";
        }
        else {
            gid("blocchargement").innerHTML = "Veuillez patienter ...";
        }

        switch (numNextForm) {
            case '1':
                /*
                 *Récupération des infos de choix 
                 *Chargement des informations personnelles              
                 */
                jQuery.ajax({
                    type: "POST",
                    url: BASE_URL + "/etudiants/add1",
                    data: "diplomeadmission=" + document.getElementById('diplomeadmission0').value +
                            //"&cursus=" + document.getElementById('cursus').value +
                            "&typeformation=" + document.getElementById('typeformation').value +
                            "&classelmd=" + document.getElementById('classelmd').value +
                            "&option1=" + document.getElementById('option1').value +
                            "&option2=" + document.getElementById('option2').value +
                            "&option3=" + document.getElementById('option3').value +
                            "&affiche=no"
                            ,
                    success: function(message) {
                        //$('#contentAdd2').replaceWith(message);
                        document.getElementById('contentNextForm').innerHTML = message;
                    }
                });
                break;

            case '2':
                /*
                 *Récupération des infos personnelles
                 *Chargement de l'adresse personnelle 
                 */

                var journaiss = getValueInTabSelect("jourNaiss");
                var moisnaiss = getValueInTabSelect("moisNaiss");
                var anneenaiss = getValueInTabSelect("anneeNaiss");
                var dateNaiss = anneenaiss + "-" + moisnaiss + "-" + journaiss;
                jQuery.ajax({
                    type: "POST",
                    url: BASE_URL + "/etudiants/add2",
                    data: "nometud=" + document.getElementById('nometud').value +
                            "&prenometud=" + document.getElementById('prenometud').value +
                            "&DateNaiss=" + dateNaiss +
                            "&lieuNaissance=" + document.getElementById('lieuNaissance').value +
                            "&RegionOrigine=" + document.getElementById('RegionOrigine').value +
                            "&premlangofficieletud=" + document.getElementById('premlangofficieletud').value +
                            "&DeptOrigine=" + document.getElementById('DeptOrigine').value +
                            "&ArrondisOrigine=" + document.getElementById('ArrondisOrigine').value +
                            //"&arrondisNew=" + document.getElementById('arrondisNew').value +
                            //"&civilite=" + document.getElementById('civilite').value +
                            "&cnietud=" + document.getElementById('cnietud').value +
                            "&sexeetud=" + document.getElementById('sexeetud').value +
                            "&nationaliteetud=" + document.getElementById('nationaliteetud').value +
                            "&situationfamilialetud=" + document.getElementById('situationfamilialetud').value +
                            "&nbreenfantetud=" + document.getElementById('nbreenfantetud').value +
                            "&situationemploietud=" + document.getElementById('situationemploietud').value +
                            "&handicape=" + document.getElementById('handicape').value +
                            "&affiche=no"
                            ,
                    success: function(message) {
                        //$('#contentAdd1').replaceWith(message);
                        document.getElementById('contentNextForm').innerHTML = message;
                    }
                });
                break;
            case '3':
                /*
                 *Récupération de l'adresse personnelle
                 * Chargement des infos sur le diplome
                 */
                if (gid('emailetud').value != '') {
                    if (!isEmail(gid('emailetud').value)) {
                        gid("blocchargement").innerHTML = "";
                        $(function() {
                            $("#dialog-message-email-invalid").dialog({
                                modal: true,
                                buttons: {
                                    Ok: function() {
                                        $(this ).dialog("close");
                                    }
                                }
                            });
                        });

                        return;
                    }

                    if (!isEmail(gid('emailetud1').value)) {
                        gid("blocchargement").innerHTML = "";
                        $(function() {
                            $("#dialog-message-email-invalid").dialog({
                                modal: true,
                                buttons: {
                                    Ok: function() {
                                        $(this ).dialog("close");
                                    }
                                }
                            });
                        });

                        return;
                    }

                    if (gid('emailetud').value != gid('emailetud1').value) {
                        gid("blocchargement").innerHTML = "";
                        $(function() {
                            $("#dialog-message-emaildiff").dialog({
                                modal: true,
                                buttons: {
                                    Ok: function() {
                                        $(this ).dialog("close");
                                    }
                                }
                            });
                        });

                        return;
                    }

                }
                jQuery.ajax({
                    type: "POST",
                    url: BASE_URL + "/etudiants/add3",
                    data: "villeresidenceetudiant=" + document.getElementById('villeresidenceetudiant').value +
                            "&codeposte=" + document.getElementById('codeposte').value +
                            "&telephone=" + document.getElementById('telephone').value +
                            "&fax=" + document.getElementById('fax').value +
                            "&emailetud=" + document.getElementById('emailetud').value +
                            "&libelleadresse=" + document.getElementById('libelleadresse').value +
                            "&affiche=no"
                            ,
                    success: function(message) {
                        //$('#contentAdd2').replaceWith(message);
                        document.getElementById('contentNextForm').innerHTML = message;
                    }
                });
                break;
            case '4':
                /*
                 *Récupération des infos de diplome
                 * Chargement des infos sur les parents
                 */

                if (gid('notediplomeetud').value < 0 || gid('notediplomeetud').value > 20 || isNaN(gid('notediplomeetud').value)) {
                    gid("blocchargement").innerHTML = "";
                    $(function() {
                        $("#dialog-message-mark").dialog({
                            modal: true,
                            buttons: {
                                Ok: function() {
                                    $(this ).dialog("close");
                                }
                            }
                        });
                    });

                    return;
                }

                /**
                 * 
                 */
                var chaineMatNote = ""; //IDMAT1_NOTE1;IDMAT2_NOTE2
                var chaineLibMatNote = "";
                var tab = document.getElementsByTagName("input");
                for (var i = 0; i < tab.length; i++) {
                    if (tab[i].name.substr(0, 4) == "mat_") {
                        var idmat = tab[i].name.substr(4, tab[i].name.length - 4);
                        if (tab[i].value < 0 || tab[i].value > 20 || isNaN(tab[i].value)) {
                            $(function() {
                                $("#dialog-message-mark").dialog({
                                    modal: true,
                                    buttons: {
                                        Ok: function() {
                                            $(this ).dialog("close");
                                        }
                                    }
                                });
                            });
                            return;
                        }
                        chaineMatNote += idmat + '_' + tab[i].value + ';';
                    }
                }


                jQuery.ajax({
                    type: "POST",
                    url: BASE_URL + "/etudiants/add4",
                    data: "diplomeadmission=" + document.getElementById('diplomeadmission').value +
                            "&modeadmission=" + document.getElementById('idmodeadmission').value +
                            "&anneeobtensiondiplome=" + document.getElementById('anneeobtensiondiplome').value +
                            "&notediplomeetud=" + document.getElementById('notediplomeetud').value +
                            "&lieuobtention=" + document.getElementById('lieuobtention').value +
                            "&chaineMatNote=" + chaineMatNote +
                            "&affiche=no"
                            // "&mentiondiplome=" + document.getElementById('mentiondiplome').value 
                            ,
                    success: function(message) {
                        //$('#contentAdd3').replaceWith(message);
                        document.getElementById('contentNextForm').innerHTML = message;
                    }
                });
                break;
            case '5':
                /*
                 * Récupération des infos sur les parents
                 * chargement du récapitulatif de toutes les infos
                 */

                jQuery.ajax({
                    type: "POST",
                    url: BASE_URL + "/etudiants/add5",
                    data: "&nompere=" + document.getElementById('nompere').value +
                            "&professionpere=" + document.getElementById('professionpere').value +
                            "&nommere=" + document.getElementById('nommere').value +
                            "&professionmere=" + document.getElementById('professionmere').value +
                            "&codeposteparent=" + document.getElementById('codeposteparent').value +
                            "&faxparent=" + document.getElementById('faxparent').value +
                            "&telephoneparent=" + document.getElementById('telephoneparent').value +
                            "&lieuderesidenceparent=" + document.getElementById('lieuderesidenceparent').value +
                            "&adresseparent=" + document.getElementById('adresseparent').value +
                            "&affiche=no"
                            ,
                    success: function(message) {
                        //$('#contentNextForm').replaceWith(message);
                        gid('contentNextForm').innerHTML = message;
                    }
                });
                break;
            case '6':
                /*
                 *Récupération de l'adresse personnelle
                 * Chargement des infos sur le diplome
                 */


                jQuery.ajax({
                    type: "POST",
                    url: BASE_URL + "/etudiants/add6",
                    data: "affiche=no",
                    success: function(message) {
                        //$('#contentAdd2').replaceWith(message);
                        document.getElementById('contentNextForm').innerHTML = message;
                    }
                });
                break;
            case '7':
                /*
                 *Récupération de l'adresse personnelle
                 * Chargement des infos sur le diplome
                 */

                jQuery.ajax({
                    type: "POST",
                    url: BASE_URL + "/etudiants/add6",
                    data: "affiche=no",
                    success: function(message) {
                        //$('#contentAdd2').replaceWith(message);
                        document.getElementById('contentNextForm').innerHTML = message;
                    }
                });
                break;
        }
//     if(window.navigator.appName.substr(0,9) != "Microsoft") {
//         gid("blocchargement").innerHTML = "";
//     }
        return false;
    }
    return false;
}
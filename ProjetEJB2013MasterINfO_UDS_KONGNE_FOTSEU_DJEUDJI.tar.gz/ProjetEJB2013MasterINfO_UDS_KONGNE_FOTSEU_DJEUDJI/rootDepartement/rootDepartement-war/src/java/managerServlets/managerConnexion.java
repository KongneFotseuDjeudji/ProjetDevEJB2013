/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package managerServlets;

import beanssessions.gestionaireConnexionLocal;
import entites.Utilisateur;
import java.io.IOException;
import java.io.PrintWriter;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author Thierrynems
 */
@WebServlet(name = "managerConnexion", urlPatterns = {"/managerConnexion"})
public class managerConnexion extends HttpServlet {

    /**
     * Processes requests for both HTTP
     * <code>GET</code> and
     * <code>POST</code> methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        
        try {
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet managerConnexion</title>");            
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Servlet managerConnexion at " + request.getContextPath() + "</h1>");
            out.println("</body>");
            out.println("</html>");
        } finally {            
            out.close();
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP
     * <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP
     * <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
       // processRequest(request, response);
       //recuperation des paramètre de connexion 
        String login=request.getParameter("login");
        String passwd=request.getParameter("motpasse");
        try{
            Context context = new InitialContext();
            gestionaireConnexionLocal con=(gestionaireConnexionLocal)context.lookup("ContactBean");
                      
             Utilisateur user=(Utilisateur)con.getInfoUsers(login, passwd);
         //    System.out.println("login="+user.getLogin()+" passwd= "+user.getPasswd());
             if(user.getLogin().equals(login) && user.getPasswd().equals(passwd)){
                request.setAttribute("connexion", 1);
                RequestDispatcher dp = request.getRequestDispatcher("Accueil.jsp");  
                dp.forward(request, response);
             }else{
               //  out.println("<span>echec de Connexion<span>");
              //   System.out.println("login="+user.getLogin());
                // RequestDispatcher dp = request.getRequestDispatcher("index.jsp");
                // dp.forward(request, response);
             }
    }catch(NamingException e){
    e.printStackTrace();
   }catch(NullPointerException e){
       RequestDispatcher dp = request.getRequestDispatcher("index.jsp");
       dp.forward(request, response);
   }
        
 }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>
}

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package managerServlets;

import beanssessions.classeFonctionsLocal;
import entites.Annee;
import entites.Cursus;
import entites.Departement;
import entites.Enseignant;
import entites.Etudiant;
import entites.Heure;
import entites.Matiere;
import entites.Matiereprogrammee;
import entites.Matiereue;
import entites.Minuite;
import entites.Noteevaluation;
import entites.Options;
import entites.Plagehoraire;
import entites.Programme;
import entites.Programmeadopte;
import entites.Ressources;
import entites.Salle;
import entites.Semestre;
import entites.Session;
import entites.Surveillant;
import entites.Ue;
import java.io.IOException;
import java.util.Collection;
import java.util.Date;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author Ernest
 */
@WebServlet(name = "managerFonctions", urlPatterns = {"/managerFonctions"})
public class managerFonctions extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // processRequest(request, response);        
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // processRequest(request, response);
    }

    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

    /*
     * Inclusions des fonctions permettant de selectionner les valeurs pour la vue
     */
    public Collection<Departement> getListsDepartement() {
        try {
            Context context = new InitialContext();
            classeFonctionsLocal con = (classeFonctionsLocal) context.lookup("accesDataBean");

            return con.getListDepartement();
        } catch (NamingException e) {
            System.out.println("Naming Exception generer=" + e.getMessage());
            return null;
        } catch (NullPointerException e) {
            System.out.println("NullPointerException generer=" + e.getMessage());
            return null;
        }
    }
    //-----fin de fonction getListsDepartement-------

    public Collection<Enseignant> getListEnseignants() {
        try {
            Context context = new InitialContext();
            classeFonctionsLocal con = (classeFonctionsLocal) context.lookup("accesDataBean");

            return con.getListEnseignant();
        } catch (NamingException e) {
            System.out.println("Naming Exception generer=" + e.getMessage());
            return null;
        } catch (NullPointerException e) {
            System.out.println("NullPointerException generer=" + e.getMessage());
            return null;
        }
    }
    //-----fin de fonction getListEnseignants---

    /*
     * fonction de retour des salles
     */
    public Collection<Salle> getListSalles() {
        try {
            Context context = new InitialContext();
            classeFonctionsLocal con = (classeFonctionsLocal) context.lookup("accesDataBean");

            return con.getListSalle();
        } catch (NamingException e) {
            System.out.println("Naming Exception generer=" + e.getMessage());
            return null;
        } catch (NullPointerException e) {
            System.out.println("NullPointerException generer=" + e.getMessage());
            return null;
        }
    }
    //-----fin de fonction getListSalles---

    /*
     * fonction de retour des plages horaires
     */
    public Collection<Plagehoraire> getListPlages() {
        try {
            Context context = new InitialContext();
            classeFonctionsLocal con = (classeFonctionsLocal) context.lookup("accesDataBean");

            return con.getListPlage();
        } catch (NamingException e) {
            System.out.println("Naming Exception generer=" + e.getMessage());
            return null;
        } catch (NullPointerException e) {
            System.out.println("NullPointerException generer=" + e.getMessage());
            return null;
        }
    }
    //-----fin de fonction getListPlages---

    /*
     * fonction de retour des heures
     */
    public Collection<Heure> getListHeures() {
        try {
            Context context = new InitialContext();
            classeFonctionsLocal con = (classeFonctionsLocal) context.lookup("accesDataBean");

            return con.getListHeure();
        } catch (NamingException e) {
            System.out.println("Naming Exception generer=" + e.getMessage());
            return null;
        } catch (NullPointerException e) {
            System.out.println("NullPointerException generer=" + e.getMessage());
            return null;
        }
    }
    //-----fin de fonction getListHeures---

    /*
     * fonction de retour des minutes
     */
    public Collection<Minuite> getListMinutes() {
        try {
            Context context = new InitialContext();
            classeFonctionsLocal con = (classeFonctionsLocal) context.lookup("accesDataBean");

            return con.getListMinute();
        } catch (NamingException e) {
            System.out.println("Naming Exception generer=" + e.getMessage());
            return null;
        } catch (NullPointerException e) {
            System.out.println("NullPointerException generer=" + e.getMessage());
            return null;
        }
    }
    //-----fin de fonction getListMinutes---
    /*
     * fonction de retour des Surveillants
     */

    public Collection<Surveillant> getListSurveillants() {
        try {
            Context context = new InitialContext();
            classeFonctionsLocal con = (classeFonctionsLocal) context.lookup("accesDataBean");

            return con.getListSurveillant();
        } catch (NamingException e) {
            System.out.println("Naming Exception generer=" + e.getMessage());
            return null;
        } catch (NullPointerException e) {
            System.out.println("NullPointerException generer=" + e.getMessage());
            return null;
        }
    }
    //-----fin de fonction getListSurveillants---
    /*
     * fonction de retour des Ressources
     */

    public Collection<Ressources> getListRessourcess() {
        try {
            Context context = new InitialContext();
            classeFonctionsLocal con = (classeFonctionsLocal) context.lookup("accesDataBean");

            return con.getListRessources();
        } catch (NamingException e) {
            System.out.println("Naming Exception generer=" + e.getMessage());
            return null;
        } catch (NullPointerException e) {
            System.out.println("NullPointerException generer=" + e.getMessage());
            return null;
        }
    }
    //-----fin de fonction getListSurveillants---

    /*
     * fonction de retour des Ressources
     */
    public Collection<Annee> getListAnnees() {
        try {
            Context context = new InitialContext();
            classeFonctionsLocal con = (classeFonctionsLocal) context.lookup("accesDataBean");

            return con.getListAnnee();
        } catch (NamingException e) {
            System.out.println("Naming Exception generer=" + e.getMessage());
            return null;
        } catch (NullPointerException e) {
            System.out.println("NullPointerException generer=" + e.getMessage());
            return null;
        }
    }
    //-----fin de fonction getListSurveillants---

    //------fonction de retour de la liste des cursus d'un departement----
    public Collection<Cursus> getListCursuss(int iddepartement) {
        try {
            Context context = new InitialContext();
            classeFonctionsLocal con = (classeFonctionsLocal) context.lookup("accesDataBean");

            return con.getListCursus(iddepartement);
        } catch (NamingException e) {
            System.out.println("Naming Exception generer=" + e.getMessage());
            return null;
        } catch (NullPointerException e) {
            System.out.println("NullPointerException generer=" + e.getMessage());
            return null;
        }
    }
    //----- fin de la fonction getListCursuss ----

    //----- fonction permetant de retourner la liste des options d'un cursus----
    public Collection<Options> getListOptionss(int idcursus) {
        try {
            Context context = new InitialContext();
            classeFonctionsLocal con = (classeFonctionsLocal) context.lookup("accesDataBean");

            return con.getListOptions(idcursus);
        } catch (NamingException e) {
            System.out.println("Naming Exception generer=" + e.getMessage());
            return null;
        } catch (NullPointerException e) {
            System.out.println("NullPointerException generer=" + e.getMessage());
            return null;
        }
    }
    //-----fin de la fonction getListOptions----

    //---fonction permettant de retourner la liste des semestres---
    public Collection<Semestre> getListSemestres() {
        try {
            Context context = new InitialContext();
            classeFonctionsLocal con = (classeFonctionsLocal) context.lookup("accesDataBean");

            return con.getListSemestre();
        } catch (NamingException e) {
            System.out.println("Naming Exception generer=" + e.getMessage());
            return null;
        } catch (NullPointerException e) {
            System.out.println("NullPointerException generer=" + e.getMessage());
            return null;
        }
    }
    //-----fin de la fonction getListSemestres--

    //---fonction permettant de retourner la liste des programmes---
    public Collection<Programme> getListProgrammes() {
        try {
            Context context = new InitialContext();
            classeFonctionsLocal con = (classeFonctionsLocal) context.lookup("accesDataBean");

            return con.getListProgramme();
        } catch (NamingException e) {
            System.out.println("Naming Exception generer=" + e.getMessage());
            return null;
        } catch (NullPointerException e) {
            System.out.println("NullPointerException generer=" + e.getMessage());
            return null;
        }
    }
    //-----fin de la fonction

    //---fonction permettant de retourner la liste des programmes---
    public Collection<Session> getListSessions(int idannee) {
        try {
            Context context = new InitialContext();
            classeFonctionsLocal con = (classeFonctionsLocal) context.lookup("accesDataBean");

            return con.getListSession(idannee);
        } catch (NamingException e) {
            System.out.println("Naming Exception generer=" + e.getMessage());
            return null;
        } catch (NullPointerException e) {
            System.out.println("NullPointerException generer=" + e.getMessage());
            return null;
        }
    }
    //-----fin de la fonction

    //---fonction permettant de retourner la liste des programmes adoptés---
    public Collection<Programmeadopte> getListProgrammeadoptes() {
        try {
            Context context = new InitialContext();
            classeFonctionsLocal con = (classeFonctionsLocal) context.lookup("accesDataBean");

            return con.getListProgrammeadopte();
        } catch (NamingException e) {
            System.out.println("Naming Exception generer=" + e.getMessage());
            return null;
        } catch (NullPointerException e) {
            System.out.println("NullPointerException generer=" + e.getMessage());
            return null;
        }
    }
    //-----fin de la fonction

    //---fonction permettant de retourner la liste des programmes adoptés---
    public Collection<Options> getOptionsByIdoptions(int idOption) {
        try {
            Context context = new InitialContext();
            classeFonctionsLocal con = (classeFonctionsLocal) context.lookup("accesDataBean");

            return con.getOptionsByIdoption(idOption);
        } catch (NamingException e) {
            System.out.println("Naming Exception generer=" + e.getMessage());
            return null;
        } catch (NullPointerException e) {
            System.out.println("NullPointerException generer=" + e.getMessage());
            return null;
        }
    }
    //-----fin de la fonction

    //---fonction permettant de retourner le programme adopté d'un semestre---
    public Collection<Programme> getProgrammeadoptes(int idAnnee, int idOptions, int idSemestre) {
        try {
            Context context = new InitialContext();
            classeFonctionsLocal con = (classeFonctionsLocal) context.lookup("accesDataBean");

            return con.getProgrammeadopte(idAnnee, idOptions, idSemestre);
        } catch (NamingException e) {
            System.out.println("Naming Exception generer=" + e.getMessage());
            return null;
        } catch (NullPointerException e) {
            System.out.println("NullPointerException generer=" + e.getMessage());
            return null;
        }
    }
    //-----fin de la fonction

    //---fonction permettant de retourner les UE d'un programme---
    public Collection<Ue> getListUEProgrammes(int idProgramme) {
        try {
            Context context = new InitialContext();
            classeFonctionsLocal con = (classeFonctionsLocal) context.lookup("accesDataBean");

            return con.getListUEProgramme(idProgramme);
        } catch (NamingException e) {
            System.out.println("Naming Exception generer=" + e.getMessage());
            return null;
        } catch (NullPointerException e) {
            System.out.println("NullPointerException generer=" + e.getMessage());
            return null;
        }
    }
    //-----fin de la fonction

    //---fonction permettant de retourner les matieres de l'UE---
    public Collection<Matiereue> getListMatiereUEs(int idUE) {
        try {
            Context context = new InitialContext();
            classeFonctionsLocal con = (classeFonctionsLocal) context.lookup("accesDataBean");

            return con.getListMatiereUE(idUE);
        } catch (NamingException e) {
            System.out.println("Naming Exception generer=" + e.getMessage());
            return null;
        } catch (NullPointerException e) {
            System.out.println("NullPointerException generer=" + e.getMessage());
            return null;
        }
    }
    //-----fin de la fonction

    //---fonction permettant de retourner une matiere à partir de son id---
    public Matiere getMatiereIds(int idMatiere) {
        try {
            Context context = new InitialContext();
            classeFonctionsLocal con = (classeFonctionsLocal) context.lookup("accesDataBean");

            return con.getMatiereId(idMatiere);
        } catch (NamingException e) {
            System.out.println("Naming Exception generer=" + e.getMessage());
            return null;
        } catch (NullPointerException e) {
            System.out.println("NullPointerException generer=" + e.getMessage());
            return null;
        }
    }
    //-----fin de la fonction

    //---fonction permettant de retourner une annee à partir de son id---
    public Annee getAnneeByIds(int idannee) {
        try {
            Context context = new InitialContext();
            classeFonctionsLocal con = (classeFonctionsLocal) context.lookup("accesDataBean");

            return con.getAnneeById(idannee);
        } catch (NamingException e) {
            System.out.println("Naming Exception generer=" + e.getMessage());
            return null;
        } catch (NullPointerException e) {
            System.out.println("NullPointerException generer=" + e.getMessage());
            return null;
        }
    }
    //-----fin de la fonction
    //---fonction permettant de retourner un departement à partir de son id---

    public Departement getDepartementByIds(int iddepartement) {
        try {
            Context context = new InitialContext();
            classeFonctionsLocal con = (classeFonctionsLocal) context.lookup("accesDataBean");

            return con.getDepartementById(iddepartement);
        } catch (NamingException e) {
            System.out.println("Naming Exception generer=" + e.getMessage());
            return null;
        } catch (NullPointerException e) {
            System.out.println("NullPointerException generer=" + e.getMessage());
            return null;
        }
    }
    //-----fin de la fonction
    //---fonction permettant de retourner un cursus à partir de son id---

    public Cursus getCursusByIds(int idcursus) {
        try {
            Context context = new InitialContext();
            classeFonctionsLocal con = (classeFonctionsLocal) context.lookup("accesDataBean");

            return con.getCursusById(idcursus);
        } catch (NamingException e) {
            System.out.println("Naming Exception generer=" + e.getMessage());
            return null;
        } catch (NullPointerException e) {
            System.out.println("NullPointerException generer=" + e.getMessage());
            return null;
        }
    }
    //-----fin de la fonction
    //---fonction permettant de retourner une option à partir de son id---

    public Options getOptionByIds(int idoptions) {
        try {
            Context context = new InitialContext();
            classeFonctionsLocal con = (classeFonctionsLocal) context.lookup("accesDataBean");

            return con.getOptionById(idoptions);
        } catch (NamingException e) {
            System.out.println("Naming Exception generer=" + e.getMessage());
            return null;
        } catch (NullPointerException e) {
            System.out.println("NullPointerException generer=" + e.getMessage());
            return null;
        }
    }
    //-----fin de la fonction
    //---fonction permettant de retourner un semestre à partir de son id---

    public Semestre getSemestreByIds(int idSemestre) {
        try {
            Context context = new InitialContext();
            classeFonctionsLocal con = (classeFonctionsLocal) context.lookup("accesDataBean");

            return con.getSemestreById(idSemestre);
        } catch (NamingException e) {
            System.out.println("Naming Exception generer=" + e.getMessage());
            return null;
        } catch (NullPointerException e) {
            System.out.println("NullPointerException generer=" + e.getMessage());
            return null;
        }
    }
    //-----fin de la fonction
    //---fonction permettant de retourner une session à partir de son id---

    public Session getSessionByIds(int idSession) {
        try {
            Context context = new InitialContext();
            classeFonctionsLocal con = (classeFonctionsLocal) context.lookup("accesDataBean");

            return con.getSessionById(idSession);
        } catch (NamingException e) {
            System.out.println("Naming Exception generer=" + e.getMessage());
            return null;
        } catch (NullPointerException e) {
            System.out.println("NullPointerException generer=" + e.getMessage());
            return null;
        }
    }
    //-----fin de la fonction

    //---fonction permettant de retourner la liste des semestres d'une classe---
    public Collection<Semestre> getSemestreByClasses(String classe) {
        try {
            Context context = new InitialContext();
            classeFonctionsLocal con = (classeFonctionsLocal) context.lookup("accesDataBean");
            
            return con.getSemestreByClasse(classe);
        } catch (NamingException e) {
            System.out.println("Naming Exception generer=" + e.getMessage());
            return null;
        } catch (NullPointerException e) {
            System.out.println("NullPointerException generer=" + e.getMessage());
            return null;
        }
    }
    //-----fin de la fonction getSemestreByClasses--

    //---fonction permettant de retourner la liste des etudiants inscrits---
    public Collection<Etudiant> getListEtudiants(int idclasse, int idannee, int idoptions) {
        try {
            Context context = new InitialContext();
            classeFonctionsLocal con = (classeFonctionsLocal) context.lookup("accesDataBean");

            return con.getListEtudiant(idclasse, idannee, idoptions);
        } catch (NamingException e) {
            System.out.println("Naming Exception generer=" + e.getMessage());
            return null;
        } catch (NullPointerException e) {
            System.out.println("NullPointerException generer=" + e.getMessage());
            return null;
        }
    }
    //-----fin de la fonction getSemestreByClasses--

    //---fonction permettant de retourner la derniere note de l'etuadiant a la matiere---
    public Noteevaluation returnLastNoteEtudMats(int idMatiere, int idEtudiant) {
        try {
            Context context = new InitialContext();
            classeFonctionsLocal con = (classeFonctionsLocal) context.lookup("accesDataBean");
            try{
                 return con.returnLastNoteEtudMat(idMatiere, idEtudiant);
            }catch (Exception e) {
                    return null;
                }           
            
        } catch (NamingException e) {
            System.out.println("Naming Exception generer=" + e.getMessage());
            return null;
        } catch (NullPointerException e) {
            System.out.println("NullPointerException generer=" + e.getMessage());
            return null;
        }
    }
    //-----fin de la fonction getSemestreByClasses--

    //---fonction permettant de retourner la derniere note de l'etuadiant a la matiere---
    public float returnMoyenneUE(int idUE, int idEtudiant){
        try {
            Context context = new InitialContext();
            classeFonctionsLocal con = (classeFonctionsLocal) context.lookup("accesDataBean");

            Collection<Matiereue> listmat = con.getListMatiereUE(idUE);
            float somme = 0;
            float sommeCredit = 0;
            int compte=0;
            for (Matiereue em : listmat) {
                int idMatiere = em.getIdMatiere();
                if("Optionnelle".equals(em.getType().toString()))
                {
                try{
                    Noteevaluation nt = con.returnLastNoteEtudMat(idMatiere, idEtudiant);
                    if(nt.getNotefinale()<em.getNoteval()){
                         return -1;
                    }else{
                      somme = somme + (nt.getNotefinale() * em.getCredit());
                      sommeCredit = sommeCredit + em.getCredit();
                      compte++;
                    }                   
                 }catch (Exception e){}
                }else{
                try{
                    Noteevaluation nt = con.returnLastNoteEtudMat(idMatiere, idEtudiant);
                    if(nt.getNotefinale()<em.getNoteval()){
                         return -1;
                    }else{
                      somme = somme + (nt.getNotefinale() * em.getCredit());
                      sommeCredit = sommeCredit + em.getCredit();
                    }                   
                 }catch (Exception e) {
                    return -1;
                    }
                }
            }//--fin de la boucle---
            try{
               Ue infoUE=con.getInfoUeById(idUE);
               int nbreMatchoix=infoUE.getNbrematopchoisie();
               
               if(nbreMatchoix==compte)
               {
               float moy = somme / sommeCredit;
                return moy;
               }else{
                return -1;
               }
            }catch (Exception e) {
                   return -1; 
                }             
        } catch (NamingException e) {
            System.out.println("Naming Exception generer=" + e.getMessage());
            return -1;
        } catch (NullPointerException e) {
            System.out.println("NullPointerException generer=" + e.getMessage());
            return -1;
        }
    }
    //-----fin de la fonction getSemestreByClasses--
    
    //---fonction permettant de retourner la derniere note de l'etuadiant a la matiere---
    public Ue getInfoUeByIds(int idUE){
        try {
            Context context = new InitialContext();
            classeFonctionsLocal con = (classeFonctionsLocal) context.lookup("accesDataBean");
            try{
                 return con.getInfoUeById(idUE);
            }catch (Exception e) {
                    return null;
                }           
            
        } catch (NamingException e) {
            System.out.println("Naming Exception generer=" + e.getMessage());
            return null;
        } catch (NullPointerException e) {
            System.out.println("NullPointerException generer=" + e.getMessage());
            return null;
        }
    }
    //-----fin de la fonction getInfoUeByIds--
    
    /*
     * Fonction permettant de retourner 
     * les points de qualités
     */
    public String[] getPointQualite(float note)
    {
     String Grade;
     String PQ;
     String RQ;
     String CodeMention;
     String tabString[] = new String[20];
     if(note>=0 && note<6)
     {
      Grade="F";
      PQ="0";
      RQ="Mauvais";
      CodeMention="Ma";
      tabString[0]=Grade;
      tabString[1]=PQ;
      tabString[2]=RQ;
      tabString[3]=CodeMention;
     }else if(note>=6 && note<7)
     {
      Grade="E";
      PQ="0,4";
      RQ="Mauvais";
      CodeMention="Ma";
      tabString[0]=Grade;
      tabString[1]=PQ;
      tabString[2]=RQ;
      tabString[3]=CodeMention;
     }else if(note>=7 && note<8)
     {
      Grade="D";
      PQ="0,8";
      RQ="Mediocre";
      CodeMention="M";
      tabString[0]=Grade;
      tabString[1]=PQ;
      tabString[2]=RQ;
      tabString[3]=CodeMention;
     }else if(note>=8 && note<9)
     {
      Grade="D+";
      PQ="1,2";
      RQ="Mediocre";
      CodeMention="M";
      tabString[0]=Grade;
      tabString[1]=PQ;
      tabString[2]=RQ;
      tabString[3]=CodeMention;
     }else if(note>=9 && note<10)
     {
      Grade="C-";
      PQ="1,6";
      RQ="Mediocre";
      CodeMention="M";
      tabString[0]=Grade;
      tabString[1]=PQ;
      tabString[2]=RQ;
      tabString[3]=CodeMention;
     }else if(note>=10 && note<11)
     {
      Grade="C";
      PQ="2";
      RQ="Passable";
      CodeMention="P";
      tabString[0]=Grade;
      tabString[1]=PQ;
      tabString[2]=RQ;
      tabString[3]=CodeMention;
     }else if(note>=11 && note<12)
     {
      Grade="C+";
      PQ="2,3";
      RQ="Passable";
      CodeMention="P";
      tabString[0]=Grade;
      tabString[1]=PQ;
      tabString[2]=RQ;
      tabString[3]=CodeMention;
     }else if(note>=12 && note<13)
     {
      Grade="B-";
      PQ="2,7";
      RQ="Assez Bien";
      CodeMention="AB";
      tabString[0]=Grade;
      tabString[1]=PQ;
      tabString[2]=RQ;
      tabString[3]=CodeMention;
     }else if(note>=13 && note<14)
     {
      Grade="B";
      PQ="3";
      RQ="Assez Bien";
      CodeMention="AB";
      tabString[0]=Grade;
      tabString[1]=PQ;
      tabString[2]=RQ;
      tabString[3]=CodeMention;
     }else if(note>=14 && note<15)
     {
      Grade="B+";
      PQ="3,3";
      RQ="Bien";
      CodeMention="B";
      tabString[0]=Grade;
      tabString[1]=PQ;
      tabString[2]=RQ;
      tabString[3]=CodeMention;
     }else if(note>=15 && note<16)
     {
      Grade="A-";
      PQ="3,7";
      RQ="Très Bien";
      CodeMention="TB";
      tabString[0]=Grade;
      tabString[1]=PQ;
      tabString[2]=RQ;
      tabString[3]=CodeMention;
     }else if(note>=16 && note<18)
     {
      Grade="A";
      PQ="3,9";
      RQ="Excellent";
      CodeMention="EX";
      tabString[0]=Grade;
      tabString[1]=PQ;
      tabString[2]=RQ;
      tabString[3]=CodeMention;
     }else if(note>=18 && note<=20)
     {
      Grade="A+";
      PQ="4";
      RQ="Excellent";
      CodeMention="EX";
      tabString[0]=Grade;
      tabString[1]=PQ;
      tabString[2]=RQ;
      tabString[3]=CodeMention;
     }
     
     return tabString;
    }//----FIN de la fonction getPointQualite(float note)---
    
    //---fonction permettant de retourner la liste des etudiants inscrits---
    public Etudiant getEtudiantByIdss(int idEtudiant){
        try{
            Context context = new InitialContext();
            classeFonctionsLocal con = (classeFonctionsLocal) context.lookup("accesDataBean");

            return con.getEtudiantByIds(idEtudiant);
        } catch (NamingException e){
            System.out.println("Naming Exception generer=" + e.getMessage());
            return null;
        } catch (NullPointerException e){
            System.out.println("NullPointerException generer=" + e.getMessage());
            return null;
        }
    }
    //-----fin de la fonction getSemestreByClasses--
    
    //---fonction permettant de retourner la liste des etudiants inscrits---
    public Collection<Enseignant> getEnseignantByIdDepts(int idDepartement){
        try{
            Context context = new InitialContext();
            classeFonctionsLocal con = (classeFonctionsLocal) context.lookup("accesDataBean");

            return con.getEnseignantByIdDept(idDepartement); 
        } catch (NamingException e){
            System.out.println("Naming Exception generer=" + e.getMessage());
            return null;
        } catch (NullPointerException e){
            System.out.println("NullPointerException generer=" + e.getMessage());
            return null;
        }
    }
    //-----fin de la fonction getSemestreByClasses--
    
    //---fonction permettant de retourner les matieres d'un programme adopté---
    public Collection<Matiere> getListMatierePrgAdoptes(int idAnnee,int idOptions,int idSemestre){
        try {
            Context context = new InitialContext();
            classeFonctionsLocal con = (classeFonctionsLocal) context.lookup("accesDataBean");

            return con.getListMatierePrgAdopte(idAnnee, idOptions, idSemestre);            
        } catch (NamingException e) {
            System.out.println("Naming Exception generer=" + e.getMessage());
            return null;
        } catch (NullPointerException e) {
            System.out.println("NullPointerException generer=" + e.getMessage());
            return null;
        }
    }
    //-----fin de la fonction
    
    //---fonction permettant de retourner la liste des Matieres programmees---
    public Collection<Matiereprogrammee> getListMatiereprogrammees(int idSession){
        try {
            Context context = new InitialContext();
            classeFonctionsLocal con = (classeFonctionsLocal) context.lookup("accesDataBean");

            return con.getListMatiereprogrammee(idSession);            
        } catch (NamingException e) {
            System.out.println("Naming Exception generer=" + e.getMessage());
            return null;
        } catch (NullPointerException e) {
            System.out.println("NullPointerException generer=" + e.getMessage());
            return null;
        }
    }
    //-----fin de la fonction
    
    //---fonction permettant de retourner les differentes dates des Matieres programmees---
     public Collection<Date> getDistinctDateMats(int idSession){
        try {
            Context context = new InitialContext();
            classeFonctionsLocal con = (classeFonctionsLocal) context.lookup("accesDataBean");

            return con.getDistinctDateMat(idSession);             
        } catch (NamingException e) {
            System.out.println("Naming Exception generer=" + e.getMessage());
            return null;
        } catch (NullPointerException e) {
            System.out.println("NullPointerException generer=" + e.getMessage());
            return null;
        }
    }
    //-----fin de la fonction
    
     //---fonction permettant de retourner les differentes plages des Matieres programmees---
     public Collection<Plagehoraire> getListPlageMatPrgs(int idSession){
        try {
            Context context = new InitialContext();
            classeFonctionsLocal con = (classeFonctionsLocal) context.lookup("accesDataBean");

            return con.getListPlageMatPrg(idSession);             
        } catch (NamingException e) {
            System.out.println("Naming Exception generer=" + e.getMessage());
            return null;
        } catch (NullPointerException e) {
            System.out.println("NullPointerException generer=" + e.getMessage());
            return null;
        }
    }
    //-----fin de la fonction
     
     //---fonction permettant de retourner une salle a partir de son id---
     public Salle getSalleByIds(int idSalle){
        try {
            Context context = new InitialContext();
            classeFonctionsLocal con = (classeFonctionsLocal) context.lookup("accesDataBean");

            return con.getSalleById(idSalle);             
        } catch (NamingException e) {
            System.out.println("Naming Exception generer=" + e.getMessage());
            return null;
        } catch (NullPointerException e) {
            System.out.println("NullPointerException generer=" + e.getMessage());
            return null;
        }
    }
    //-----fin de la fonction
     
     //---fonction permettant de retourner l'heure a partir de son id---
     public Heure getHeureByIds(int idHeure){
        try {
            Context context = new InitialContext();
            classeFonctionsLocal con = (classeFonctionsLocal) context.lookup("accesDataBean");

            return con.getHeureById(idHeure);             
        } catch (NamingException e) {
            System.out.println("Naming Exception generer=" + e.getMessage());
            return null;
        } catch (NullPointerException e) {
            System.out.println("NullPointerException generer=" + e.getMessage());
            return null;
        }
    }
    //-----fin de la fonction
     //---fonction permettant de retourner la minute a partir de son id---
     public Minuite getMinuteByIds(int idMinute){
        try {
            Context context = new InitialContext();
            classeFonctionsLocal con = (classeFonctionsLocal) context.lookup("accesDataBean");

            return con.getMinuteById(idMinute);             
        } catch (NamingException e) {
            System.out.println("Naming Exception generer=" + e.getMessage());
            return null;
        } catch (NullPointerException e) {
            System.out.println("NullPointerException generer=" + e.getMessage());
            return null;
        }
    }
    //-----fin de la fonction
     
     //---fonction permettant de retourner l'option d'une matiere d'un programme---
     public Options getOptionMatierePrgAdoptes(int idAnnee,int idSemestre){
        try {
            Context context = new InitialContext();
            classeFonctionsLocal con = (classeFonctionsLocal) context.lookup("accesDataBean");

            return con.getOptionMatierePrgAdopte(idAnnee, idSemestre);              
        } catch (NamingException e) {
            System.out.println("Naming Exception generer=" + e.getMessage());
            return null;
        } catch (NullPointerException e) {
            System.out.println("NullPointerException generer=" + e.getMessage());
            return null;
        }
    }
    //-----fin de la fonction
     
}//----fin de servlet-------

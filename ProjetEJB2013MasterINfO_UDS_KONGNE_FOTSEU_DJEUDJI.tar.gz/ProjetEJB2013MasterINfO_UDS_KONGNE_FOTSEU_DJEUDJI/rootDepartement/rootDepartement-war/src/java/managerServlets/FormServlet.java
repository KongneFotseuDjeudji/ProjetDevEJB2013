/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package managerServlets;

import beanssessions.ManagerFormAllLocal;
import entites.Session;
import java.io.IOException;
import java.io.PrintWriter;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author Thierrynems
 */
@WebServlet(name = "FormServlet", urlPatterns = {"/FormServlet"})
public class FormServlet extends HttpServlet {

    /**
     * Processes requests for both HTTP
     * <code>GET</code> and
     * <code>POST</code> methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
       /* try {
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet FormServlet</title>");            
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Servlet FormServlet at " + request.getContextPath() + "</h1>");
            out.println("</body>");
            out.println("</html>");
        } finally {            
            out.close();
        }
        */
        
         
        
        
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP
     * <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP
     * <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        //processRequest(request, response);
        String form=request.getParameter("form");
        if(form.equals("EnregEtud")){
            //partie formulaire enregistrement des etudiants 
        Integer idannee= Integer.parseInt(request.getParameter("annee"));
        Integer idcursus= Integer.parseInt(request.getParameter("cursus"));
        Integer idoption= Integer.parseInt(request.getParameter("option"));
        Integer idclasse= Integer.parseInt(request.getParameter("classe"));
        String nometudiant=request.getParameter("nometudiant");
        String prenometudiant=request.getParameter("prenometudiant");
        String cni=request.getParameter("cni");
        String datenaisse=request.getParameter("datenais");
        String lieunaiss=request.getParameter("lieunaiss");
        String nationalite=request.getParameter("nationalite");
        String sexeetud=request.getParameter("sexeetud");
        String langueetud=request.getParameter("langueetud");
        String diplomeadmis=request.getParameter("diplomeadmis");
        String photoetud=request.getParameter("photoetud");
        Date datenais=null;
        try{
                SimpleDateFormat formatter = new SimpleDateFormat("YYYY-MM-DD");
                datenais = formatter.parse(datenaisse);
                
            }catch(RuntimeException e) {
			
	  } catch (ParseException ex) {
            Logger.getLogger(FormServlet.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        try{
            Context context = new InitialContext();
            ManagerFormAllLocal objRemote=(ManagerFormAllLocal)context.lookup("formsBean");
            Boolean isInsert=objRemote.insertEtudiant(nometudiant,prenometudiant,datenais,lieunaiss,nationalite,sexeetud,langueetud,photoetud,diplomeadmis,cni,idclasse,idannee,idoption,idcursus);
            if(isInsert){
                request.setAttribute("isInsert", "ok");
                RequestDispatcher dp = request.getRequestDispatcher("Accueil.jsp?page=SaisieEtudiant.jsp");  
                dp.forward(request, response);
            }else{
                request.setAttribute("isInsert", "ko");
                RequestDispatcher dp = request.getRequestDispatcher("Accueil.jsp?page=SaisieEtudiant.jsp");  
                dp.forward(request, response);
            }
            
        }catch(NamingException e){
            
        }
        //fin enreg etud
      }  else if(form.equals("EnregSession")){
          
              //partie formulaire enregistrement des etudiants 
        Integer idannee= Integer.parseInt(request.getParameter("annee"));
        String codesession=request.getParameter("codesession");
        String libellefr=request.getParameter("libellefr");
        String libelleen=request.getParameter("libelleen");
        String typesession=request.getParameter("typesession");
        try{
            Context context = new InitialContext();
            ManagerFormAllLocal objRemote=(ManagerFormAllLocal)context.lookup("formsBean");
            Session ses=new Session();
            ses.setCodesession(codesession);
            ses.setEncours(false);
            ses.setIdannee(idannee);
            ses.setLibelleEn(libelleen);
            ses.setLibelleFr(libellefr);
            ses.setNumsession(0);
            ses.setTypesession(typesession);
            Boolean isInsert=objRemote.InsertSession(ses);
            if(isInsert){
                request.setAttribute("isInsert", "ok");
                RequestDispatcher dp = request.getRequestDispatcher("Accueil.jsp?page=SaisieSession.jsp");  
                dp.forward(request, response);
            }else{
                request.setAttribute("isInsert", "ko");
                RequestDispatcher dp = request.getRequestDispatcher("Accueil.jsp?page=SaisieSession.jsp");  
                dp.forward(request, response);
            }
            
        }catch(NamingException e){
            
        }
           
      }
        
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>
}

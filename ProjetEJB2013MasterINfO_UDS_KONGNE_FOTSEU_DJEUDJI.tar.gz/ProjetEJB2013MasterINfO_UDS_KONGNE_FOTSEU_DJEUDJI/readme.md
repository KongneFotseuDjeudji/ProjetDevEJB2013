Read de deployement du projet de developpement: 
/*
* Gestion d'un departement académique: Conception et developpement des 
* modules de gestion pédagogiques de gestion de notes et de *consultation des proflis des etudiants
*/
0- Rassurez que les outils suivants sont installés: 
	- jboss version 6.0 final et plus
	- jdk 6 et plus 
	- serveur de base de données mysql 

1- configuration de la datasource dans jboss 
- copier le fichier bdprojetjava-mysql-ds.xml qui se trouve à la racine du dossier du projet et le coller dans le repertoire $jbossHome/server/default/deploy
- editer ce fichier et remplacer les paramètres de conexion au SGBD mysql par vos propres paramètres.
- copier le fichier mysql-connector-java-5.1.26-bin.jar qui se trouve à la racine du dossier du projet et coller dans le repertoire $jbosshome/server/default/lib
- redemarer votre serveur jboss

2- creation de la base de données dans mysql 
- lancer un client mysql et exécuter le scripts sql qui se trouve à la racine du dossier du projet. le fichier sql est nommé: bdprojetjava.sql
- ignorer la sensibilité à la casse de votre SGBD mysql en copier cette ligne : 
"lower_case_table_names=1" à la rubrique [mysqld] et redemarer le service mysql.

3- deployement de l'application
vous avez deux possiblités de deployement : 
- copier le fichier rootDepartement.ear et coller dans $jbossHome/server/default/deploy et lancer votre navigateur à l'adresse suivante: http://localhost:8080/rootDepartement-war 
et connecter vous en utilisant les paramètres par default:
login: admin
password: admin

- copier le repertoire rootDepartement et coller dans votre repertoire personnel des projets, lancer votre editeur Eclipse ou Netbeans et ajouter le projet et le deployer.
connecter avec les même paramètres indiqués ci-dessus (login: admin  pass: admin )

4- explorer le projet

5- vous pouvez aussi visualiser les différents etats produits par l'application dans le dossier pdf qui se trouve au dossier racine

FIN

